<!DOCTYPE html> 
<html lang="en-US"> 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v18.0 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Brighter Skills</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Brighter Skills" />
	<meta property="og:site_name" content="Brighter Skills" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://brighter.techcraze.co.in/#website","url":"https://brighter.techcraze.co.in/","name":"Brighter Skills","description":"(AIM education &amp; Research Society initiative)","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://brighter.techcraze.co.in/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Brighter Skills &raquo; Feed" href="https://brighter.techcraze.co.in/feed/" />
<link rel="alternate" type="application/rss+xml" title="Brighter Skills &raquo; Comments Feed" href="https://brighter.techcraze.co.in/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/brighter.techcraze.co.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.9"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='jquery-ui-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/css/jquery-ui.css?ver=1.12.1' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/css/animate.min.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/css/font-awesome-5.min.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='wppb-fonts-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/css/wppb-fonts.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='wppb-addons-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/css/wppb-addons.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='wppb-main-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/css/wppb-main.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://brighter.techcraze.co.in/wp-includes/css/dist/block-library/style.min.css?ver=5.9' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code>code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group:where(.has-background){padding:1.25em 2.375em}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}
</style>
<link rel='stylesheet' id='wc-blocks-vendors-style-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=6.5.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-style-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=6.5.2' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel='stylesheet' id='tutor-icon-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/icons/css/tutor-icon.css?ver=1.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='tutor-plyr-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/packages/plyr/plyr.css?ver=1.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='tutor-frontend-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/css/tutor-front.min.css?ver=1.9.3' type='text/css' media='all' />
<style id='tutor-frontend-inline-css' type='text/css'>
:root{}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=6.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=6.1.1' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=6.1.1' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='buttons-css'  href='https://brighter.techcraze.co.in/wp-includes/css/buttons.min.css?ver=5.9' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://brighter.techcraze.co.in/wp-includes/css/dashicons.min.css?ver=5.9' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='https://brighter.techcraze.co.in/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.16' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css'  href='https://brighter.techcraze.co.in/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.9' type='text/css' media='all' />
<link rel='stylesheet' id='media-views-css'  href='https://brighter.techcraze.co.in/wp-includes/css/media-views.min.css?ver=5.9' type='text/css' media='all' />
<link rel='stylesheet' id='imgareaselect-css'  href='https://brighter.techcraze.co.in/wp-includes/js/imgareaselect/imgareaselect.css?ver=0.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap.min-css'  href='https://brighter.techcraze.co.in/wp-content/themes/docent/css/bootstrap.min.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-css-css'  href='https://brighter.techcraze.co.in/wp-content/themes/docent/css/woocommerce.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome.min-css'  href='https://brighter.techcraze.co.in/wp-content/themes/docent/css/fontawesome.min.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='docent-main-css'  href='https://brighter.techcraze.co.in/wp-content/themes/docent/css/main.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='docent-responsive-css'  href='https://brighter.techcraze.co.in/wp-content/themes/docent/css/responsive.css?ver=all' type='text/css' media='all' />
<link rel='stylesheet' id='docent-style-css'  href='https://brighter.techcraze.co.in/wp-content/themes/docent/style.css?ver=5.9' type='text/css' media='all' />
<style id='docent-style-inline-css' type='text/css'>

                    a,
                    .widget ul li a:hover,
                    body.woocommerce-account .woocommerce-MyAccount-navigation ul li:hover a,
                    body.woocommerce-account .woocommerce-MyAccount-navigation ul li.is-active a,
                    .tutor-courses-grid-price span.woocommerce-Price-amount.amount,
                    .blog-post-review-pre p.prev, 
                    .tutor-course-topics-contents .tutor-course-title h4 i,
                    .header-cat-menu ul li a:hover,
                    .blog-post-review-next p.next,
                    .blog-post-review-pre:hover i,
                    #bottom-wrap .docent-social-share a:hover,
                    .bottom-widget .mc4wp-form-fields button,
                    .article-details h3.article-title a:hover,
                    .rticle-introtext a.blog-btn-wrap,
                    .section-content-second .article-details h3.article-title a:hover,
                    .blog-post-review-next:hover i,
                    .bottom-widget .docent-mailchimp i.fa.fa-long-arrow-right,
                    .docent-custom-link-widget li a i,
                    .blog-navigation ul li.active a, 
                    .blog-navigation ul li a:hover,
                    .blog-content-wrapper span.post-category a, 
                    .blog-content-wrapper span.post-category,
                    .blog-content-wrapper .thm-profile-content i,
                    #footer-wrap a:hover,
                    .docent-pagination .page-numbers li a:hover,
                    .docent-pagination .page-numbers li span.current,
                    .docent-pagination .page-numbers li a.next.page-numbers:hover, 
                    .docent-pagination .page-numbers li a.prev:hover,
                    .docent-pagination span.fa-angle-left, 
                    .docent-pagination .next.page-numbers i.fa.fa-angle-right, 
                    .docent-pagination .page-numbers i.fa.fa-angle-left,
                    .tutor-courses-grid-price .price,
                    .docent-post.hentry .blog-post-meta, 
                    .docent-post.hentry .blog-post-meta li a, 
                    .blog-post-meta li span,
                    #sidebar .widget_categories ul li a:hover,
                    .page-numbers li span:hover, 
                    .page-numbers li a.page-numbers:hover,
                    .docent-pagination .page-numbers li a.page-numbers:hover,
                    .btn.btn-border-docent,
                    .docent-widgets a:hover,
                    #mobile-menu ul li a:hover,
                    #mobile-menu ul li.active>a,
                    .page-numbers li span:hover, 
                    .social-share-wrap ul li a:hover,
                    .docent-post .blog-post-meta li i,
                    .docent-post .blog-post-meta li a,
                    .bottom-widget .widget ul li a:hover,
                    .page-numbers li a.page-numbers:hover, 
                    .main-menu-wrap .navbar-toggle:hover,
                    .docent-pagination .page-numbers li a,
                    .docent-post .blog-post-meta li a:hover,
                    .docent-post .content-item-title a:hover,
                    .docent-post .content-item-title a:hover,
                    .bottom-widget .mc4wp-form-fields button,
                    #sidebar .widget_categories ul li a:hover, 
                    .article-details h3.article-title a:hover,  
                    #bottom-wrap .docent-social-share a:hover, 
                    .docent-pagination .page-numbers li a:hover,  
                    .docent-pagination .page-numbers li span.current, 
                    .entry-summary .wrap-btn-style a.btn-style:hover,
                    .widget-blog-posts-section .entry-title  a:hover,
                    .entry-header h2.entry-title.blog-entry-title a:hover, 
                    .header-solid .common-menu-wrap .nav>li.active>a:after,
                    .section-content-second .article-details h3.article-title a:hover, 
                    #wp-megamenu-primary>.wpmm-nav-wrap ul.wp-megamenu>li.current-menu-ancestor>a,
                    #wp-megamenu-primary>.wpmm-nav-wrap ul.wp-megamenu>li ul.wp-megamenu-sub-menu li:hover>a,
                    #wp-megamenu-primary>.wpmm-nav-wrap ul.wp-megamenu>li ul.wp-megamenu-sub-menu li.active>a,
                    #wp-megamenu-primary>.wpmm-nav-wrap ul.wp-megamenu>li ul.wp-megamenu-sub-menu li.current-menu-item>a,
                    #wp-megamenu-primary>.wpmm-nav-wrap .wp-megamenu>li>ul.wp-megamenu-sub-menu li.wpmm-type-widget:hover>a,
                    .docent-pagination .page-numbers li a.next.page-numbers:hover, .docent-pagination .page-numbers li a.prev:hover,
                    ul.wp-block-archives li a, .wp-block-categories li a, .wp-block-latest-posts li a { color: #1b52d8; }
                    .info-wrapper a.white,
                    .docent-login-remember input:checked + span,
                    .call-to-action a.btn:hover,
                    .docent-signin-popup-body button.register_button,
                    form#login .btn-fill,
                    .docent-error-wrapper a.btn.btn-secondary,
                    .call-to-action a.btn.btn2,
                    .blog-content-wrapper a.blog-button.btn.btn-success,
                    .wpmm_mobile_menu_btn,
                    #sidebar h3.widget_title:before,
                    .docent-widgets span.blog-cat:before,
                    .single_related:hover .overlay-content,
                    .order-view .label-info,
                    .footer-mailchamp .mc4wp-form-fields input[type=submit],
                    .error-log input[type=submit],
                    .widget .tagcloud a:hover,
                    .wpmm_mobile_menu_btn:hover,
                    .wpmm-gridcontrol-left:hover, 
                    .wpmm-gridcontrol-right:hover,
                    .form-submit input[type=submit],
                    .header-top .social-share ul li a:hover,
                    .single_related:hover .overlay-content,.page-numbers li .current:before
                    { background: #1b52d8; }
                    input:focus,
                    form#login .btn-fill,
                    .footer-mailchamp .mc4wp-form-fields input[type="email"]:focus,
                    .tutor-course-archive-filters-wrap .nice-select:after,
                    keygen:focus,
                    .docent-signin-popup-body button.register_button,
                    .error-log input[type=submit],
                    .comments-area .comment-form input[type=text]:focus,
                    .comments-area textarea:focus,
                    .title-content-wrap .qubely-block-text-title code,
                    .blog-comments-section .form-submit .submit,
                    .error-log input[type=submit],
                    .footer-mailchamp .mc4wp-form-fields input[type=submit],
                    select:focus,
                    .wpcf7-submit,
                    .call-to-action a.btn,
                    textarea:focus,
                    .blog-arrows a:hover,
                    .btn.btn-border-docent,
                    .wpcf7-form input:focus,
                    .btn.btn-border-white:hover,
                    .wpmm-gridcontrol-left:hover, 
                    .wpmm-gridcontrol-right:hover,
                    .common-menu-wrap .nav>li.current>a,
                    .docent-latest-post-content .entry-title a:hover,
                    .header-solid .common-menu-wrap .nav>li.current>a,
                    .latest-review-single-layout2 .latest-post-title a:hover,
                    .info-wrapper a.white:hover, .bottom-widget .mc4wp-form input[type="email"]:focus
                    { border-color: #1b52d8; }    
                    .wpcf7-submit:hover,
                    .post-meta-info-list-in a:hover,
                    .mc4wp-form-fields .send-arrow button,
                    .comingsoon .mc4wp-form-fields input[type=submit] {   
                        background-color: #1b52d8; border-color: #1b52d8; 
                    }
                    a:hover,
                    .footer-copyright a:hover,
                    .widget.widget_rss ul li a,
                    .entry-summary .wrap-btn-style a.btn-style:hover{ color: #1b52d8; }.error-page-inner a.btn.btn-primary.btn-lg:hover,
                    input[type=button]:hover,
                    .widget.widget_search #searchform .btn-search:hover,
                     .order-view .label-info:hover
                     { background-color: #1b52d8; }.bottom-widget .mc4wp-form input[type="email"]:focus{ border-color: #1b52d8; }body {font-size:14px;font-family:Poppins;font-weight: 400;line-height: 27px;color: #535967;}.common-menu-wrap .nav>li>a {font-size:14px;font-family:Poppins;font-weight: 700;line-height: 54px;color: #1f2949;}h1 {font-size:46px;font-family:Montserrat;font-weight: 700;line-height: 42px;color: #1f2949;}h2 {font-size:30px;font-family:Poppins;font-weight: 600;line-height: 36px;color: #1f2949;}h3 {font-size:24px;font-family:Poppins;font-weight: 400;line-height: 28px;color: #1f2949;}h4 {font-size:18px;font-family:Poppins;font-weight: 600;line-height: 26px;color: #1f2949;}h5 {font-size:14px;font-family:Poppins;font-weight: 600;line-height: 26px;color: #1f2949;}.single_add_to_cart_button,a.tutor-button,.tutor-button,a.tutor-btn,.tutor-btn, .course-complete-button, .docent-single-container .woocommerce-message .wc-forward, .tutor-course-enrolled-review-wrap .write-course-review-link-btn, .header-cat-menu ul li a, .header_profile_menu ul li a, .blog-date-wrapper time, .docent-pagination .page-numbers li a, .footer-mailchamp, #footer-wrap,.common-menu-wrap .nav>li>ul li a {font-family:Poppins}.site-header{ margin-bottom: 0px; }.site-header{ background-color: #ffffff;}.site-header.sticky.header-transparent .main-menu-wrap{ margin-top: 0;}.site-header.sticky{ background-color: #ffffff;}.docent-navbar-header img{width:300px; max-width:none;}.subtitle-cover h2{font-size:34px;color:#1b52d8;}.breadcrumb>li+li:before, .subtitle-cover .breadcrumb, .subtitle-cover .breadcrumb>.active{color:#000;}
        .site-header .primary-menu{
            padding:0px 0 0px; 
        }
        .subtitle-cover{
            padding:80px 0 70px; 
        }body{ background-color: #fff; }input[type=submit],
                    .btn.btn-border-docent:hover,.btn.btn-border-white:hover{ background-color: #1b52d8; border-color: #1b52d8; color: #fff !important; border-radius: 4px; }.docent-login-register a.docent-dashboard, .docent-widgets span.blog-cat:before, #sidebar h3.widget_title:before{ background-color: #1b52d8; }input[type=submit]:hover{ background-color: #1b52d8; border-color: #1b52d8; color: #fff !important; }.docent-login-register a.docent-dashboard:hover{ background-color: #1b52d8; }.header-solid .common-menu-wrap .nav>li.menu-item-has-children:after, .header-borderimage .common-menu-wrap .nav>li.menu-item-has-children:after, .header-solid .common-menu-wrap .nav>li>a, .header-borderimage .common-menu-wrap .nav>li>a, .header-transparent .common-menu-wrap .nav>li>a,
            .header-transparent .common-menu-wrap .nav>li.menu-item-has-children > a:after,
            .header-solid .common-menu-wrap .nav>li>a:after, .header-borderimage .common-menu-wrap .nav>li>a:after,.docent-search,
            .primary-menu .common-menu-wrap .nav>li>a { color: #1f2949; }.header-solid .common-menu-wrap .nav>li>a:hover, .header-borderimage .common-menu-wrap .nav>li>a:hover,.docent-login-register ul li a,.header-solid .common-menu-wrap .nav>li>a:hover:after, .header-borderimage .common-menu-wrap .nav>li>a:hover:after,
        .docent-search-wrap a.docent-search:hover, .primary-menu .common-menu-wrap .nav>li>a:hover,
        .header-common-menu a.docent-search.search-open-icon:hover, .common-menu .docent-search.search-close-icon:hover { color: #1b52d8; }.common-menu-wrap .nav>li.current-menu-item > a, .common-menu-wrap .nav>li.current-menu-parent > a { color: #1b52d8; }.common-menu-wrap .nav>li ul{ background-color: #f8f8f8; }.common-menu-wrap .nav>li>ul li a,.common-menu-wrap .nav > li > ul li.mega-child > a, .header_profile_menu ul li a{ color: #535967; border-color: #eef0f2; }.common-menu-wrap .nav>li>ul li a:hover,.common-menu-wrap .sub-menu > li.active > a,
        .common-menu-wrap .nav>li>ul li a:hover, .header_profile_menu ul li a:hover,
        .common-menu-wrap .sub-menu li.active.mega-child a:hover{ color: #1b52d8;}.common-menu-wrap .nav>li > ul::after{ border-color: transparent transparent #f8f8f8 transparent; }.footer-mailchamp{ background-color: #fbfbfc; }.footer-mailchamp .newslatter{ padding-top: 70px; }.footer-mailchamp .newslatter{ padding-bottom: 0px; }#bottom-wrap{ background-color: #fbfbfc; }#bottom-wrap,.bottom-widget .widget h3.widget-title{ color: #1f2949; }#bottom-wrap a, #menu-footer-menu li a{ color: #535967; }#bottom-wrap .docent-widgets .latest-widget-date, #bottom-wrap .bottom-widget ul li, div.about-desc, .bottom-widget .textwidget p{ color: #535967; }#bottom-wrap a:hover{ color: #1b52d8; }#bottom-wrap{ padding-top: 60px; }#bottom-wrap{ padding-bottom: 0px; }#footer-wrap{ color: #6c6d8b; }#footer-wrap a{ color: #6c6d8b; }#footer-wrap{ background-color: #fbfbfc; }#footer-wrap{ padding-top: 30px; }#footer-wrap a:hover{ color: #1b52d8; }#footer-wrap{ padding-bottom: 20px; }#footer-wrap a, #footer-wrap .text-right { color: #535967; }.docent-error{
            width: 100%;
            height: 100%;
            min-height: 100%;
            background-color: #fff;
            background-size: cover;
        }.coming-soon-main-wrap{
            width: 100%;
            height: 100vh;
            min-height: 100vh;
            background-image: url(https://brighter.techcraze.co.in/wp-content/themes/docent);
            background-size: cover;
            background-repeat: no-repeat;
            background-color: #202D56;
        }
</style>
<link rel='stylesheet' id='tm-google-font-css'  href='//fonts.googleapis.com/css?family=Poppins%3A400%2C700%2C600%2C400%2C600%2C600%7CMontserrat%3A700&#038;ver=5.9' type='text/css' media='all' />
<link rel='stylesheet' id='wppb-posts-css-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/addons/posts/assets/css/posts-addon.css?ver=5.9' type='text/css' media='all' />
<link rel='stylesheet' id='tmm-css'  href='https://brighter.techcraze.co.in/wp-content/plugins/team-members/inc/css/tmm_style.css?ver=5.9' type='text/css' media='all' />
<script type='text/javascript' id='qubely_local_script-js-extra'>
/* <![CDATA[ */
var qubely_urls = {"plugin":"https:\/\/brighter.techcraze.co.in\/wp-content\/plugins\/qubely\/","ajax":"https:\/\/brighter.techcraze.co.in\/wp-admin\/admin-ajax.php","nonce":"e5eb71583d","actual_url":"brighter.techcraze.co.in"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' id='qubely_container_width-js-extra'>
/* <![CDATA[ */
var qubely_container_width = {"sm":"540","md":"720","lg":"960","xl":"1140"};
/* ]]> */
</script>
<script type='text/javascript' id='utils-js-extra'>
/* <![CDATA[ */
var userSettings = {"url":"\/","uid":"0","time":"1645106040","secure":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/utils.min.js?ver=5.9' id='utils-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/plupload/moxie.min.js?ver=1.3.5' id='moxiejs-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/plupload/plupload.min.js?ver=2.1.9' id='plupload-js'></script>
<!--[if lt IE 8]>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/json2.min.js?ver=2015-05-03' id='json2-js'></script>
<![endif]-->
<link rel="https://api.w.org/" href="https://brighter.techcraze.co.in/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://brighter.techcraze.co.in/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://brighter.techcraze.co.in/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.9" />
<meta name="generator" content="TutorLMS 1.9.3" />
<meta name="generator" content="WooCommerce 6.1.1" />
<!-- OG TAGS -->
<meta property="og:site_name" content="Brighter Skills">
<meta property="fb:admins" content="">
<meta property="og:title" content="Page not found - Brighter Skills Brighter Skills">
<meta property="og:description" content="(AIM education &amp; Research society initiative)">
<meta property="og:url" content="https://brighter.techcraze.co.in/xmlrpc.php">
<meta property="og:type" content="website"> 
<meta property="og:image" content="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-cropped-brighter-skills-heading.png">
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-cropped-brighter-skills-heading-32x32.png" sizes="32x32" />
<link rel="icon" href="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-cropped-brighter-skills-heading-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-cropped-brighter-skills-heading-180x180.png" />
<meta name="msapplication-TileImage" content="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-cropped-brighter-skills-heading-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			/** Home - Courses 3Cols **/
@media (min-width: 768px) {
.tutor-widget-course-loop.tutor-widget-course {
    width: 33.1%;
    padding: 0 7px;
		display: inline-block;
}
}

.tutor-loop-author .tutor-course-lising-category {
    display: none;
}

.tutor-loop-course-footer {
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.tutor-single-course-meta ul li a {
    overflow-wrap: break-word;
}

.tutor-widget-course-loop.tutor-widget-course {
    margin-bottom: 40px;
}

/** Mobiel Phone **/
@media (max-width: 767px) {

.tutor-course-loop-meta {
    display: none;
}

.tutor-loop-author {
    display: none;
}

.tutor-loop-course-container {
    padding: 25px 10px 1px 10px;
}
}


/** Font Family for Single Course Page **/
.tutor-wrap{
    font-family: poppins;
}

/** Footer Menu Block **/
#bottom-wrap .bottom-widget .widget_nav_menu ul li {
    display: block;
	
}
.widget_nav_menu ul li {
    display: block;
	margin-bottom: 5px;
}
ul.themeum-social-share {
    padding: 0;
}


		</style>
		</head>

<body class="error404 wp-custom-logo theme-docent qubely qubely-frontend woocommerce-no-js fullwidth-bg body-content">  
    <a class="skip-link screen-reader-text" href="#content">Skip to the content</a>	 
	<div id="page" class="hfeed site fullwidth">
	<header id="masthead" class="site-header header-white  enable-sticky  ">  	
	<div class="container">
		<div class="primary-menu">
			<div class="row align-items-center">
				
									<div class="clearfix col-md-auto col-10">
						<div class="docent-navbar-header">
							<div class="logo-wrapper">
								
								<a href="https://brighter.techcraze.co.in/" class="custom-logo-link" rel="home"><img width="702" height="205" src="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-brighter-skills-heading.png" class="custom-logo" alt="Brighter Skills" srcset="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-brighter-skills-heading.png 702w, https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-brighter-skills-heading-300x88.png 300w, https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-brighter-skills-heading-700x205.png 700w, https://brighter.techcraze.co.in/wp-content/uploads/2021/05/cropped-brighter-skills-heading-600x175.png 600w" sizes="(max-width: 702px) 100vw, 702px" /></a>							</div>   
						</div> <!--/#docent-navbar-header-->   
					</div> <!--/.col-sm-2-->
				
				<!-- Mobile Monu -->
									<div class="col-md-auto col-2 ml-auto docent-menu hidden-lg-up">
						<button id="hamburger-menu" type="button" class="navbar-toggle hamburger-menu-button" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="hamburger-menu-button-open"></span>
						</button>
					</div>
					<div id="mobile-menu" class="thm-mobile-menu"> 
						<div class="collapse navbar-collapse">
							<ul id="menu-menu-1" class="nav navbar-nav"><li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-47"><a title="Home" href="https://brighter.techcraze.co.in/">Home</a></li>
<li id="menu-item-51" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51"><a title="All Courses" href="https://brighter.techcraze.co.in/courses">All Courses</a></li>
<li id="menu-item-48" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-48"><a title="Dashboard" href="https://brighter.techcraze.co.in/dashboard/">Dashboard</a></li>
<li id="menu-item-63" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-63"><a title="Register" href="https://brighter.techcraze.co.in">Register</a>
                <span class="menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-63">
                <i class="fas fa-angle-right"></i>
                </span>
<ul role="menu" class="collapse collapse-63 ">
	<li id="menu-item-49" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-49"><a title="Instructor Registration" href="https://brighter.techcraze.co.in/instructor-registration/">Instructor Registration</a></li>
	<li id="menu-item-50" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-50"><a title="Student Registration" href="https://brighter.techcraze.co.in/student-registration/">Student Registration</a></li>
</ul>
</li>
<li id="menu-item-71" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-71"><a title="Our Policy&#039;s" href="https://brighter.techcraze.co.in">Our Policy's</a>
                <span class="menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-71">
                <i class="fas fa-angle-right"></i>
                </span>
<ul role="menu" class="collapse collapse-71 ">
	<li id="menu-item-62" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62"><a title="About Us." href="https://brighter.techcraze.co.in/about-us/">About Us.</a></li>
	<li id="menu-item-149" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-149"><a title="Privacy Policy" href="https://brighter.techcraze.co.in/privacy-policy/">Privacy Policy</a></li>
	<li id="menu-item-70" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-70"><a title="Refund Policy" href="https://brighter.techcraze.co.in/refund-policy/">Refund Policy</a></li>
	<li id="menu-item-93" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-93"><a title="TERMS OF SERVICE" href="https://brighter.techcraze.co.in/terms-of-service/">TERMS OF SERVICE</a></li>
</ul>
</li>
<li id="menu-item-94" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-94 active"><a title="Blog" href="https://brighter.techcraze.co.in/blog/">Blog</a></li>
</ul>						</div>
					</div> <!-- thm-mobile-menu -->
								

				<!-- Primary Menu -->
									<div class="col-auto ml-auto common-menu space-wrap d-none d-lg-block">
									<div class="header-common-menu">
													<div id="main-menu" class="common-menu-wrap">
								<ul id="menu-menu-2" class="nav"><li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-47"><a href="https://brighter.techcraze.co.in/">Home</a></li>
<li id="menu-item-51" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51"><a href="https://brighter.techcraze.co.in/courses">All Courses</a></li>
<li id="menu-item-48" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-48"><a href="https://brighter.techcraze.co.in/dashboard/">Dashboard</a></li>
<li id="menu-item-63" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-63"><a href="https://brighter.techcraze.co.in">Register</a>
<ul class="sub-menu">
	<li id="menu-item-49" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-49"><a href="https://brighter.techcraze.co.in/instructor-registration/">Instructor Registration</a></li>
	<li id="menu-item-50" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-50"><a href="https://brighter.techcraze.co.in/student-registration/">Student Registration</a></li>
</ul>
</li>
<li id="menu-item-71" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-71"><a href="https://brighter.techcraze.co.in">Our Policy&#8217;s</a>
<ul class="sub-menu">
	<li id="menu-item-62" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62"><a href="https://brighter.techcraze.co.in/about-us/">About Us.</a></li>
	<li id="menu-item-149" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-149"><a href="https://brighter.techcraze.co.in/privacy-policy/">Privacy Policy</a></li>
	<li id="menu-item-70" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-70"><a href="https://brighter.techcraze.co.in/refund-policy/">Refund Policy</a></li>
	<li id="menu-item-93" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-93"><a href="https://brighter.techcraze.co.in/terms-of-service/">TERMS OF SERVICE</a></li>
</ul>
</li>
<li id="menu-item-94" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-94"><a href="https://brighter.techcraze.co.in/blog/">Blog</a></li>
</ul>  
							</div><!--/.col-sm-9-->  
											</div><!-- header-common-menu -->
				</div><!-- common-menu -->
			</div>
		</div> 
	</div><!--/.container--> 

	<!-- Header Progress. -->
						<div class="docent-progress">
				<progress value="0" max="1">
					<span class="progress-bar"></span>    
				</progress>
			</div>
			</header> <!-- header -->		

	

	
<div class="docent-error">
	<div class="docent-error-wrapper" style="background-image: url()">
		<div class="row">
		    <div class="col-md-12 info-wrapper">
		    	<p class="error-message">
					The Page you are looking for does not exit				</p>
	            <a href="https://brighter.techcraze.co.in/" class="btn btn-secondary">
	            	Go Home	            </a>
		    </div>
	    </div>
	</div>
</div>
<section class="footer-bottom">
     <!-- Footer Widgets -->
     

    <!-- Footer Widgets -->
                    <div id="bottom-wrap"  class="footer"> 
            <div class="container">
                <div class="row clearfix border-wrap">
                                            <div class="col-sm-6 col-md-6 col-lg-3">
                            <div class="bottom-widget"><div id="text-2" class="widget widget_text" ><h3 class="widget-title">Contact Us.</h3>			<div class="textwidget"><p>208 IInd Floor, Sakina Complex, Mehdipatnam Cross Road, Above Maharaja Sweets, Hyderabad, Telangana 500028</p>
<p>Phone no: 914066347861 &amp; 9640948311<br />
Mail info@brighter.techcraze.co.in</p>
</div>
		</div></div><div class="widget_text bottom-widget"><div id="custom_html-2" class="widget_text widget widget_custom_html" ><h3 class="widget-title">Follow us on.</h3><div class="textwidget custom-html-widget"><ul class="themeum-social-share">
	<li><a class="facebook" href="#" target="_blank" rel="noopener"><i class="fab fa-facebook-f"></i></a></li>			
	<li><a class="twitter" href="#" target="_blank" rel="noopener"><i class="fab fa-twitter"></i></a></li>
	<li><a class="linkedin" href="#" target="_blank" rel="noopener"><i class="fab fa-linkedin"></i></a></li>
	<li><a class="pinterest" href="#" target="_blank" rel="noopener"><i class="fab fa-pinterest"></i></a></li>
</ul></div></div></div>                        </div>
                     
                                            <div class="col-sm-6 col-md-6 col-lg-3">
                            <div class="bottom-widget"><div id="nav_menu-2" class="widget widget_nav_menu" ><h3 class="widget-title">Quick Links</h3><div class="menu-footer1-container"><ul id="menu-footer1" class="menu"><li id="menu-item-84" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-84"><a href="https://brighter.techcraze.co.in/">Home</a></li>
<li id="menu-item-89" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-89"><a href="http://brighterskills.com/cources">All Cources</a></li>
<li id="menu-item-83" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-83"><a href="https://brighter.techcraze.co.in/dashboard/">Dashboard</a></li>
<li id="menu-item-91" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-91"><a href="http://brighterskills.com">Register</a>
<ul class="sub-menu">
	<li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-81"><a href="https://brighter.techcraze.co.in/instructor-registration/">Instructor Registration</a></li>
	<li id="menu-item-82" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-82"><a href="https://brighter.techcraze.co.in/student-registration/">Student Registration</a></li>
</ul>
</li>
<li id="menu-item-92" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-92"><a href="https://brighter.techcraze.co.in">Our policy&#8217;s</a>
<ul class="sub-menu">
	<li id="menu-item-80" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-80"><a href="https://brighter.techcraze.co.in/about-us/">About Us.</a></li>
	<li id="menu-item-86" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-86"><a href="https://brighter.techcraze.co.in/refund-policy/">Refund Policy</a></li>
	<li id="menu-item-87" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-87"><a href="https://brighter.techcraze.co.in/terms-of-service/">TERMS OF SERVICE</a></li>
	<li id="menu-item-88" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-88"><a href="https://brighter.techcraze.co.in/privacy-policy/">Privacy Policy</a></li>
</ul>
</li>
<li id="menu-item-85" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-85"><a href="https://brighter.techcraze.co.in/blog/">Blog</a></li>
</ul></div></div></div>                        </div>
                                                                <div class="col-sm-6 col-md-6 col-lg-3">
                            <div class="bottom-widget"><div id="nav_menu-3" class="widget widget_nav_menu" ><h3 class="widget-title">Menu</h3><div class="menu-menu-1-container"><ul id="menu-menu-3" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-47"><a href="https://brighter.techcraze.co.in/">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-51"><a href="https://brighter.techcraze.co.in/courses">All Courses</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-48"><a href="https://brighter.techcraze.co.in/dashboard/">Dashboard</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-63"><a href="https://brighter.techcraze.co.in">Register</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-49"><a href="https://brighter.techcraze.co.in/instructor-registration/">Instructor Registration</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-50"><a href="https://brighter.techcraze.co.in/student-registration/">Student Registration</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-71"><a href="https://brighter.techcraze.co.in">Our Policy&#8217;s</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62"><a href="https://brighter.techcraze.co.in/about-us/">About Us.</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-149"><a href="https://brighter.techcraze.co.in/privacy-policy/">Privacy Policy</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-70"><a href="https://brighter.techcraze.co.in/refund-policy/">Refund Policy</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-93"><a href="https://brighter.techcraze.co.in/terms-of-service/">TERMS OF SERVICE</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-94"><a href="https://brighter.techcraze.co.in/blog/">Blog</a></li>
</ul></div></div></div>                        </div>  
                      
                                     
                        <div class="col-sm-6 col-md-6 col-lg-3">
                            <div class="bottom-widget"><div id="woocommerce_products-2" class="widget woocommerce widget_products" ><h3 class="widget-title">Products</h3><ul class="product_list_widget"><li>
	
	<a href="https://brighter.techcraze.co.in/product/mba/">
		<img width="300" height="300" src="https://brighter.techcraze.co.in/wp-content/uploads/woocommerce-placeholder.png" class="woocommerce-placeholder wp-post-image" alt="Placeholder" loading="lazy" />		<span class="product-title">MBA</span>
	</a>

				
	<del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>660000</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>570000</bdi></span></ins>
	</li>
<li>
	
	<a href="https://brighter.techcraze.co.in/product/mondly-language-learning/">
		<img width="300" height="168" src="https://brighter.techcraze.co.in/wp-content/uploads/2021/06/mondly1.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />		<span class="product-title">Mondly Language Learning</span>
	</a>

				
	<del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>4000</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>1800</bdi></span></ins>
	</li>
<li>
	
	<a href="https://brighter.techcraze.co.in/product/ielts-coaching/">
		<img width="275" height="172" src="https://brighter.techcraze.co.in/wp-content/uploads/2021/05/ielts-1.png" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" loading="lazy" />		<span class="product-title">IELTS Coaching</span>
	</a>

				
	<del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>10000</bdi></span></del> <ins><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>8500</bdi></span></ins>
	</li>
</ul></div></div>                        </div>
                      
                </div>
            </div>
        </div><!--/#bottom-wrap-->
    </section>

    <footer id="footer-wrap"> 
        <div class="container">
            <div class="row clearfix">
                                                <div class="col-sm-12 col-md-12 text-center">
                                                            2021 AIM education Society. All Rights Reserved.                     
                </div>

            </div><!--/.row clearfix-->    
        </div><!--/.container-->    
    </footer><!--/#footer-wrap-->    

</div> <!-- #page -->
<div class='tutor-cart-box-login-form' style='display: none;'><span class='login-overlay-close'></span><div class='tutor-cart-box-login-form-inner'><button class='tutor-popup-form-close tutor-icon-line-cross'></button>
<div class="tutor-single-course-segment tutor-course-login-wrap">
    <div class="course-login-title">
        <h4>Login</h4>
    </div>

    <div class="tutor-single-course-login-form">
	    
<div class="tutor-login-form-wrap">
	
    
	<form name="loginform" id="loginform" method="post">

	
	<input type="hidden" id="_tutor_nonce" name="_tutor_nonce" value="408d35243c" /><input type="hidden" name="_wp_http_referer" value="/xmlrpc.php" />	
	<input type="hidden" name="tutor_action" value="tutor_user_login" />
		<p class="login-username">
			<input type="text" placeholder="Username or Email Address" name="log" id="user_login" class="input" value="" size="20" />
		</p>

		<p class="login-password">
			<input type="password" placeholder="Password" name="pwd" id="user_pass" class="input" value="" size="20"/>
		</p>
		
		

		<div class="tutor-login-rememeber-wrap">
						<p class="login-remember">
				<label>
					<input name="rememberme" type="checkbox" id="rememberme" 
					value="forever"
					 					>
					Remember Me				</label>
			</p>
					    <a href="https://brighter.techcraze.co.in/dashboard/retrieve-password">
		    	Forgot Password?		    </a>
		</div>
		
		
		<p class="login-submit">
			<input type="submit" name="wp-submit" id="wp-submit" class="tutor-button" value="Log In" />
			<input type="hidden" name="redirect_to" value="https://brighter.techcraze.co.in/xmlrpc.php" />
		</p>
		
						<p class="tutor-form-register-wrap">
					<a href="https://brighter.techcraze.co.in/student-registration/?redirect_to=https://brighter.techcraze.co.in/product/ielts-coaching/">
						Create a new account					</a>
				</p>
					</form>

    </div>
    </div>
</div>
</div></div>
		<script type="text/html" id="tmpl-media-frame">
		<div class="media-frame-title" id="media-frame-title"></div>
		<h2 class="media-frame-menu-heading">Actions</h2>
		<button type="button" class="button button-link media-frame-menu-toggle" aria-expanded="false">
			Menu			<span class="dashicons dashicons-arrow-down" aria-hidden="true"></span>
		</button>
		<div class="media-frame-menu"></div>
		<div class="media-frame-tab-panel">
			<div class="media-frame-router"></div>
			<div class="media-frame-content"></div>
		</div>
		<h2 class="media-frame-actions-heading screen-reader-text">
		Selected media actions		</h2>
		<div class="media-frame-toolbar"></div>
		<div class="media-frame-uploader"></div>
	</script>

		<script type="text/html" id="tmpl-media-modal">
		<div tabindex="0" class="media-modal wp-core-ui" role="dialog" aria-labelledby="media-frame-title">
			<# if ( data.hasCloseButton ) { #>
				<button type="button" class="media-modal-close"><span class="media-modal-icon"><span class="screen-reader-text">Close dialog</span></span></button>
			<# } #>
			<div class="media-modal-content" role="document"></div>
		</div>
		<div class="media-modal-backdrop"></div>
	</script>

		<script type="text/html" id="tmpl-uploader-window">
		<div class="uploader-window-content">
			<div class="uploader-editor-title">Drop files to upload</div>
		</div>
	</script>

		<script type="text/html" id="tmpl-uploader-editor">
		<div class="uploader-editor-content">
			<div class="uploader-editor-title">Drop files to upload</div>
		</div>
	</script>

		<script type="text/html" id="tmpl-uploader-inline">
		<# var messageClass = data.message ? 'has-upload-message' : 'no-upload-message'; #>
		<# if ( data.canClose ) { #>
		<button class="close dashicons dashicons-no"><span class="screen-reader-text">Close uploader</span></button>
		<# } #>
		<div class="uploader-inline-content {{ messageClass }}">
		<# if ( data.message ) { #>
			<h2 class="upload-message">{{ data.message }}</h2>
		<# } #>
					<div class="upload-ui">
				<h2 class="upload-instructions drop-instructions">Drop files to upload</h2>
				<p class="upload-instructions drop-instructions">or</p>
				<button type="button" class="browser button button-hero" aria-labelledby="post-upload-info">Select Files</button>
			</div>

			<div class="upload-inline-status"></div>

			<div class="post-upload-ui" id="post-upload-info">
				
				<p class="max-upload-size">
				Maximum upload file size: 8 MB.				</p>

				<# if ( data.suggestedWidth && data.suggestedHeight ) { #>
					<p class="suggested-dimensions">
						Suggested image dimensions: {{data.suggestedWidth}} by {{data.suggestedHeight}} pixels.					</p>
				<# } #>

							</div>
				</div>
	</script>

		<script type="text/html" id="tmpl-media-library-view-switcher">
		<a href="https://brighter.techcraze.co.in/wp-admin/upload.php?mode=list" class="view-list">
			<span class="screen-reader-text">List view</span>
		</a>
		<a href="https://brighter.techcraze.co.in/wp-admin/upload.php?mode=grid" class="view-grid current" aria-current="page">
			<span class="screen-reader-text">Grid view</span>
		</a>
	</script>

		<script type="text/html" id="tmpl-uploader-status">
		<h2>Uploading</h2>

		<div class="media-progress-bar"><div></div></div>
		<div class="upload-details">
			<span class="upload-count">
				<span class="upload-index"></span> / <span class="upload-total"></span>
			</span>
			<span class="upload-detail-separator">&ndash;</span>
			<span class="upload-filename"></span>
		</div>
		<div class="upload-errors"></div>
		<button type="button" class="button upload-dismiss-errors">Dismiss errors</button>
	</script>

		<script type="text/html" id="tmpl-uploader-status-error">
		<span class="upload-error-filename">{{{ data.filename }}}</span>
		<span class="upload-error-message">{{ data.message }}</span>
	</script>

		<script type="text/html" id="tmpl-edit-attachment-frame">
		<div class="edit-media-header">
			<button class="left dashicons"<# if ( ! data.hasPrevious ) { #> disabled<# } #>><span class="screen-reader-text">Edit previous media item</span></button>
			<button class="right dashicons"<# if ( ! data.hasNext ) { #> disabled<# } #>><span class="screen-reader-text">Edit next media item</span></button>
			<button type="button" class="media-modal-close"><span class="media-modal-icon"><span class="screen-reader-text">Close dialog</span></span></button>
		</div>
		<div class="media-frame-title"></div>
		<div class="media-frame-content"></div>
	</script>

		<script type="text/html" id="tmpl-attachment-details-two-column">
		<div class="attachment-media-view {{ data.orientation }}">
			<h2 class="screen-reader-text">Attachment Preview</h2>
			<div class="thumbnail thumbnail-{{ data.type }}">
				<# if ( data.uploading ) { #>
					<div class="media-progress-bar"><div></div></div>
				<# } else if ( data.sizes && data.sizes.large ) { #>
					<img class="details-image" src="{{ data.sizes.large.url }}" draggable="false" alt="" />
				<# } else if ( data.sizes && data.sizes.full ) { #>
					<img class="details-image" src="{{ data.sizes.full.url }}" draggable="false" alt="" />
				<# } else if ( -1 === jQuery.inArray( data.type, [ 'audio', 'video' ] ) ) { #>
					<img class="details-image icon" src="{{ data.icon }}" draggable="false" alt="" />
				<# } #>

				<# if ( 'audio' === data.type ) { #>
				<div class="wp-media-wrapper wp-audio">
					<audio style="visibility: hidden" controls class="wp-audio-shortcode" width="100%" preload="none">
						<source type="{{ data.mime }}" src="{{ data.url }}" />
					</audio>
				</div>
				<# } else if ( 'video' === data.type ) {
					var w_rule = '';
					if ( data.width ) {
						w_rule = 'width: ' + data.width + 'px;';
					} else if ( wp.media.view.settings.contentWidth ) {
						w_rule = 'width: ' + wp.media.view.settings.contentWidth + 'px;';
					}
				#>
				<div style="{{ w_rule }}" class="wp-media-wrapper wp-video">
					<video controls="controls" class="wp-video-shortcode" preload="metadata"
						<# if ( data.width ) { #>width="{{ data.width }}"<# } #>
						<# if ( data.height ) { #>height="{{ data.height }}"<# } #>
						<# if ( data.image && data.image.src !== data.icon ) { #>poster="{{ data.image.src }}"<# } #>>
						<source type="{{ data.mime }}" src="{{ data.url }}" />
					</video>
				</div>
				<# } #>

				<div class="attachment-actions">
					<# if ( 'image' === data.type && ! data.uploading && data.sizes && data.can.save ) { #>
					<button type="button" class="button edit-attachment">Edit Image</button>
					<# } else if ( 'pdf' === data.subtype && data.sizes ) { #>
					<p>Document Preview</p>
					<# } #>
				</div>
			</div>
		</div>
		<div class="attachment-info">
			<span class="settings-save-status" role="status">
				<span class="spinner"></span>
				<span class="saved">Saved.</span>
			</span>
			<div class="details">
				<h2 class="screen-reader-text">Details</h2>
				<div class="uploaded"><strong>Uploaded on:</strong> {{ data.dateFormatted }}</div>
				<div class="uploaded-by">
					<strong>Uploaded by:</strong>
						<# if ( data.authorLink ) { #>
							<a href="{{ data.authorLink }}">{{ data.authorName }}</a>
						<# } else { #>
							{{ data.authorName }}
						<# } #>
				</div>
				<# if ( data.uploadedToTitle ) { #>
					<div class="uploaded-to">
						<strong>Uploaded to:</strong>
						<# if ( data.uploadedToLink ) { #>
							<a href="{{ data.uploadedToLink }}">{{ data.uploadedToTitle }}</a>
						<# } else { #>
							{{ data.uploadedToTitle }}
						<# } #>
					</div>
				<# } #>
				<div class="filename"><strong>File name:</strong> {{ data.filename }}</div>
				<div class="file-type"><strong>File type:</strong> {{ data.mime }}</div>
				<div class="file-size"><strong>File size:</strong> {{ data.filesizeHumanReadable }}</div>
				<# if ( 'image' === data.type && ! data.uploading ) { #>
					<# if ( data.width && data.height ) { #>
						<div class="dimensions"><strong>Dimensions:</strong>
							{{ data.width }} by {{ data.height }} pixels						</div>
					<# } #>

					<# if ( data.originalImageURL && data.originalImageName ) { #>
						Original image:						<a href="{{ data.originalImageURL }}">{{data.originalImageName}}</a>
					<# } #>
				<# } #>

				<# if ( data.fileLength && data.fileLengthHumanReadable ) { #>
					<div class="file-length"><strong>Length:</strong>
						<span aria-hidden="true">{{ data.fileLength }}</span>
						<span class="screen-reader-text">{{ data.fileLengthHumanReadable }}</span>
					</div>
				<# } #>

				<# if ( 'audio' === data.type && data.meta.bitrate ) { #>
					<div class="bitrate">
						<strong>Bitrate:</strong> {{ Math.round( data.meta.bitrate / 1000 ) }}kb/s
						<# if ( data.meta.bitrate_mode ) { #>
						{{ ' ' + data.meta.bitrate_mode.toUpperCase() }}
						<# } #>
					</div>
				<# } #>

				<# if ( data.mediaStates ) { #>
					<div class="media-states"><strong>Used as:</strong> {{ data.mediaStates }}</div>
				<# } #>

				<div class="compat-meta">
					<# if ( data.compat && data.compat.meta ) { #>
						{{{ data.compat.meta }}}
					<# } #>
				</div>
			</div>

			<div class="settings">
				<# var maybeReadOnly = data.can.save || data.allowLocalEdits ? '' : 'readonly'; #>
				<# if ( 'image' === data.type ) { #>
					<span class="setting has-description" data-setting="alt">
						<label for="attachment-details-two-column-alt-text" class="name">Alternative Text</label>
						<input type="text" id="attachment-details-two-column-alt-text" value="{{ data.alt }}" aria-describedby="alt-text-description" {{ maybeReadOnly }} />
					</span>
					<p class="description" id="alt-text-description"><a href="https://www.w3.org/WAI/tutorials/images/decision-tree" target="_blank" rel="noopener">Learn how to describe the purpose of the image<span class="screen-reader-text"> (opens in a new tab)</span></a>. Leave empty if the image is purely decorative.</p>
				<# } #>
								<span class="setting" data-setting="title">
					<label for="attachment-details-two-column-title" class="name">Title</label>
					<input type="text" id="attachment-details-two-column-title" value="{{ data.title }}" {{ maybeReadOnly }} />
				</span>
								<# if ( 'audio' === data.type ) { #>
								<span class="setting" data-setting="artist">
					<label for="attachment-details-two-column-artist" class="name">Artist</label>
					<input type="text" id="attachment-details-two-column-artist" value="{{ data.artist || data.meta.artist || '' }}" />
				</span>
								<span class="setting" data-setting="album">
					<label for="attachment-details-two-column-album" class="name">Album</label>
					<input type="text" id="attachment-details-two-column-album" value="{{ data.album || data.meta.album || '' }}" />
				</span>
								<# } #>
				<span class="setting" data-setting="caption">
					<label for="attachment-details-two-column-caption" class="name">Caption</label>
					<textarea id="attachment-details-two-column-caption" {{ maybeReadOnly }}>{{ data.caption }}</textarea>
				</span>
				<span class="setting" data-setting="description">
					<label for="attachment-details-two-column-description" class="name">Description</label>
					<textarea id="attachment-details-two-column-description" {{ maybeReadOnly }}>{{ data.description }}</textarea>
				</span>
				<span class="setting" data-setting="url">
					<label for="attachment-details-two-column-copy-link" class="name">File URL:</label>
					<input type="text" class="attachment-details-copy-link" id="attachment-details-two-column-copy-link" value="{{ data.url }}" readonly />
					<span class="copy-to-clipboard-container">
						<button type="button" class="button button-small copy-attachment-url" data-clipboard-target="#attachment-details-two-column-copy-link">Copy URL to clipboard</button>
						<span class="success hidden" aria-hidden="true">Copied!</span>
					</span>
				</span>
				<div class="attachment-compat"></div>
			</div>

			<div class="actions">
				<# if ( data.link ) { #>
					<a class="view-attachment" href="{{ data.link }}">View attachment page</a>
				<# } #>
				<# if ( data.can.save ) { #>
					<# if ( data.link ) { #>
						<span class="links-separator">|</span>
					<# } #>
					<a href="{{ data.editLink }}">Edit more details</a>
				<# } #>
				<# if ( ! data.uploading && data.can.remove ) { #>
					<# if ( data.link || data.can.save ) { #>
						<span class="links-separator">|</span>
					<# } #>
											<button type="button" class="button-link delete-attachment">Delete permanently</button>
									<# } #>
			</div>
		</div>
	</script>

		<script type="text/html" id="tmpl-attachment">
		<div class="attachment-preview js--select-attachment type-{{ data.type }} subtype-{{ data.subtype }} {{ data.orientation }}">
			<div class="thumbnail">
				<# if ( data.uploading ) { #>
					<div class="media-progress-bar"><div style="width: {{ data.percent }}%"></div></div>
				<# } else if ( 'image' === data.type && data.size && data.size.url ) { #>
					<div class="centered">
						<img src="{{ data.size.url }}" draggable="false" alt="" />
					</div>
				<# } else { #>
					<div class="centered">
						<# if ( data.image && data.image.src && data.image.src !== data.icon ) { #>
							<img src="{{ data.image.src }}" class="thumbnail" draggable="false" alt="" />
						<# } else if ( data.sizes && data.sizes.medium ) { #>
							<img src="{{ data.sizes.medium.url }}" class="thumbnail" draggable="false" alt="" />
						<# } else { #>
							<img src="{{ data.icon }}" class="icon" draggable="false" alt="" />
						<# } #>
					</div>
					<div class="filename">
						<div>{{ data.filename }}</div>
					</div>
				<# } #>
			</div>
			<# if ( data.buttons.close ) { #>
				<button type="button" class="button-link attachment-close media-modal-icon"><span class="screen-reader-text">Remove</span></button>
			<# } #>
		</div>
		<# if ( data.buttons.check ) { #>
			<button type="button" class="check" tabindex="-1"><span class="media-modal-icon"></span><span class="screen-reader-text">Deselect</span></button>
		<# } #>
		<#
		var maybeReadOnly = data.can.save || data.allowLocalEdits ? '' : 'readonly';
		if ( data.describe ) {
			if ( 'image' === data.type ) { #>
				<input type="text" value="{{ data.caption }}" class="describe" data-setting="caption"
					aria-label="Caption"
					placeholder="Caption&hellip;" {{ maybeReadOnly }} />
			<# } else { #>
				<input type="text" value="{{ data.title }}" class="describe" data-setting="title"
					<# if ( 'video' === data.type ) { #>
						aria-label="Video title"
						placeholder="Video title&hellip;"
					<# } else if ( 'audio' === data.type ) { #>
						aria-label="Audio title"
						placeholder="Audio title&hellip;"
					<# } else { #>
						aria-label="Media title"
						placeholder="Media title&hellip;"
					<# } #> {{ maybeReadOnly }} />
			<# }
		} #>
	</script>

		<script type="text/html" id="tmpl-attachment-details">
		<h2>
			Attachment Details			<span class="settings-save-status" role="status">
				<span class="spinner"></span>
				<span class="saved">Saved.</span>
			</span>
		</h2>
		<div class="attachment-info">

			<# if ( 'audio' === data.type ) { #>
				<div class="wp-media-wrapper wp-audio">
					<audio style="visibility: hidden" controls class="wp-audio-shortcode" width="100%" preload="none">
						<source type="{{ data.mime }}" src="{{ data.url }}" />
					</audio>
				</div>
			<# } else if ( 'video' === data.type ) {
				var w_rule = '';
				if ( data.width ) {
					w_rule = 'width: ' + data.width + 'px;';
				} else if ( wp.media.view.settings.contentWidth ) {
					w_rule = 'width: ' + wp.media.view.settings.contentWidth + 'px;';
				}
			#>
				<div style="{{ w_rule }}" class="wp-media-wrapper wp-video">
					<video controls="controls" class="wp-video-shortcode" preload="metadata"
						<# if ( data.width ) { #>width="{{ data.width }}"<# } #>
						<# if ( data.height ) { #>height="{{ data.height }}"<# } #>
						<# if ( data.image && data.image.src !== data.icon ) { #>poster="{{ data.image.src }}"<# } #>>
						<source type="{{ data.mime }}" src="{{ data.url }}" />
					</video>
				</div>
			<# } else { #>
				<div class="thumbnail thumbnail-{{ data.type }}">
					<# if ( data.uploading ) { #>
						<div class="media-progress-bar"><div></div></div>
					<# } else if ( 'image' === data.type && data.size && data.size.url ) { #>
						<img src="{{ data.size.url }}" draggable="false" alt="" />
					<# } else { #>
						<img src="{{ data.icon }}" class="icon" draggable="false" alt="" />
					<# } #>
				</div>
			<# } #>

			<div class="details">
				<div class="filename">{{ data.filename }}</div>
				<div class="uploaded">{{ data.dateFormatted }}</div>

				<div class="file-size">{{ data.filesizeHumanReadable }}</div>
				<# if ( 'image' === data.type && ! data.uploading ) { #>
					<# if ( data.width && data.height ) { #>
						<div class="dimensions">
							{{ data.width }} by {{ data.height }} pixels						</div>
					<# } #>

					<# if ( data.originalImageURL && data.originalImageName ) { #>
						Original image:						<a href="{{ data.originalImageURL }}">{{data.originalImageName}}</a>
					<# } #>

					<# if ( data.can.save && data.sizes ) { #>
						<a class="edit-attachment" href="{{ data.editLink }}&amp;image-editor" target="_blank">Edit Image</a>
					<# } #>
				<# } #>

				<# if ( data.fileLength && data.fileLengthHumanReadable ) { #>
					<div class="file-length">Length:						<span aria-hidden="true">{{ data.fileLength }}</span>
						<span class="screen-reader-text">{{ data.fileLengthHumanReadable }}</span>
					</div>
				<# } #>

				<# if ( data.mediaStates ) { #>
					<div class="media-states"><strong>Used as:</strong> {{ data.mediaStates }}</div>
				<# } #>

				<# if ( ! data.uploading && data.can.remove ) { #>
											<button type="button" class="button-link delete-attachment">Delete permanently</button>
									<# } #>

				<div class="compat-meta">
					<# if ( data.compat && data.compat.meta ) { #>
						{{{ data.compat.meta }}}
					<# } #>
				</div>
			</div>
		</div>
		<# var maybeReadOnly = data.can.save || data.allowLocalEdits ? '' : 'readonly'; #>
		<# if ( 'image' === data.type ) { #>
			<span class="setting has-description" data-setting="alt">
				<label for="attachment-details-alt-text" class="name">Alt Text</label>
				<input type="text" id="attachment-details-alt-text" value="{{ data.alt }}" aria-describedby="alt-text-description" {{ maybeReadOnly }} />
			</span>
			<p class="description" id="alt-text-description"><a href="https://www.w3.org/WAI/tutorials/images/decision-tree" target="_blank" rel="noopener">Learn how to describe the purpose of the image<span class="screen-reader-text"> (opens in a new tab)</span></a>. Leave empty if the image is purely decorative.</p>
		<# } #>
				<span class="setting" data-setting="title">
			<label for="attachment-details-title" class="name">Title</label>
			<input type="text" id="attachment-details-title" value="{{ data.title }}" {{ maybeReadOnly }} />
		</span>
				<# if ( 'audio' === data.type ) { #>
				<span class="setting" data-setting="artist">
			<label for="attachment-details-artist" class="name">Artist</label>
			<input type="text" id="attachment-details-artist" value="{{ data.artist || data.meta.artist || '' }}" />
		</span>
				<span class="setting" data-setting="album">
			<label for="attachment-details-album" class="name">Album</label>
			<input type="text" id="attachment-details-album" value="{{ data.album || data.meta.album || '' }}" />
		</span>
				<# } #>
		<span class="setting" data-setting="caption">
			<label for="attachment-details-caption" class="name">Caption</label>
			<textarea id="attachment-details-caption" {{ maybeReadOnly }}>{{ data.caption }}</textarea>
		</span>
		<span class="setting" data-setting="description">
			<label for="attachment-details-description" class="name">Description</label>
			<textarea id="attachment-details-description" {{ maybeReadOnly }}>{{ data.description }}</textarea>
		</span>
		<span class="setting" data-setting="url">
			<label for="attachment-details-copy-link" class="name">File URL:</label>
			<input type="text" class="attachment-details-copy-link" id="attachment-details-copy-link" value="{{ data.url }}" readonly />
			<div class="copy-to-clipboard-container">
				<button type="button" class="button button-small copy-attachment-url" data-clipboard-target="#attachment-details-copy-link">Copy URL to clipboard</button>
				<span class="success hidden" aria-hidden="true">Copied!</span>
			</div>
		</span>
	</script>

		<script type="text/html" id="tmpl-media-selection">
		<div class="selection-info">
			<span class="count"></span>
			<# if ( data.editable ) { #>
				<button type="button" class="button-link edit-selection">Edit Selection</button>
			<# } #>
			<# if ( data.clearable ) { #>
				<button type="button" class="button-link clear-selection">Clear</button>
			<# } #>
		</div>
		<div class="selection-view"></div>
	</script>

		<script type="text/html" id="tmpl-attachment-display-settings">
		<h2>Attachment Display Settings</h2>

		<# if ( 'image' === data.type ) { #>
			<span class="setting align">
				<label for="attachment-display-settings-alignment" class="name">Alignment</label>
				<select id="attachment-display-settings-alignment" class="alignment"
					data-setting="align"
					<# if ( data.userSettings ) { #>
						data-user-setting="align"
					<# } #>>

					<option value="left">
						Left					</option>
					<option value="center">
						Center					</option>
					<option value="right">
						Right					</option>
					<option value="none" selected>
						None					</option>
				</select>
			</span>
		<# } #>

		<span class="setting">
			<label for="attachment-display-settings-link-to" class="name">
				<# if ( data.model.canEmbed ) { #>
					Embed or Link				<# } else { #>
					Link To				<# } #>
			</label>
			<select id="attachment-display-settings-link-to" class="link-to"
				data-setting="link"
				<# if ( data.userSettings && ! data.model.canEmbed ) { #>
					data-user-setting="urlbutton"
				<# } #>>

			<# if ( data.model.canEmbed ) { #>
				<option value="embed" selected>
					Embed Media Player				</option>
				<option value="file">
			<# } else { #>
				<option value="none" selected>
					None				</option>
				<option value="file">
			<# } #>
				<# if ( data.model.canEmbed ) { #>
					Link to Media File				<# } else { #>
					Media File				<# } #>
				</option>
				<option value="post">
				<# if ( data.model.canEmbed ) { #>
					Link to Attachment Page				<# } else { #>
					Attachment Page				<# } #>
				</option>
			<# if ( 'image' === data.type ) { #>
				<option value="custom">
					Custom URL				</option>
			<# } #>
			</select>
		</span>
		<span class="setting">
			<label for="attachment-display-settings-link-to-custom" class="name">URL</label>
			<input type="text" id="attachment-display-settings-link-to-custom" class="link-to-custom" data-setting="linkUrl" />
		</span>

		<# if ( 'undefined' !== typeof data.sizes ) { #>
			<span class="setting">
				<label for="attachment-display-settings-size" class="name">Size</label>
				<select id="attachment-display-settings-size" class="size" name="size"
					data-setting="size"
					<# if ( data.userSettings ) { #>
						data-user-setting="imgsize"
					<# } #>>
											<#
						var size = data.sizes['thumbnail'];
						if ( size ) { #>
							<option value="thumbnail" >
								Thumbnail &ndash; {{ size.width }} &times; {{ size.height }}
							</option>
						<# } #>
											<#
						var size = data.sizes['medium'];
						if ( size ) { #>
							<option value="medium" >
								Medium &ndash; {{ size.width }} &times; {{ size.height }}
							</option>
						<# } #>
											<#
						var size = data.sizes['large'];
						if ( size ) { #>
							<option value="large" >
								Large &ndash; {{ size.width }} &times; {{ size.height }}
							</option>
						<# } #>
											<#
						var size = data.sizes['full'];
						if ( size ) { #>
							<option value="full"  selected='selected'>
								Full Size &ndash; {{ size.width }} &times; {{ size.height }}
							</option>
						<# } #>
									</select>
			</span>
		<# } #>
	</script>

		<script type="text/html" id="tmpl-gallery-settings">
		<h2>Gallery Settings</h2>

		<span class="setting">
			<label for="gallery-settings-link-to" class="name">Link To</label>
			<select id="gallery-settings-link-to" class="link-to"
				data-setting="link"
				<# if ( data.userSettings ) { #>
					data-user-setting="urlbutton"
				<# } #>>

				<option value="post" <# if ( ! wp.media.galleryDefaults.link || 'post' === wp.media.galleryDefaults.link ) {
					#>selected="selected"<# }
				#>>
					Attachment Page				</option>
				<option value="file" <# if ( 'file' === wp.media.galleryDefaults.link ) { #>selected="selected"<# } #>>
					Media File				</option>
				<option value="none" <# if ( 'none' === wp.media.galleryDefaults.link ) { #>selected="selected"<# } #>>
					None				</option>
			</select>
		</span>

		<span class="setting">
			<label for="gallery-settings-columns" class="name select-label-inline">Columns</label>
			<select id="gallery-settings-columns" class="columns" name="columns"
				data-setting="columns">
									<option value="1" <#
						if ( 1 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						1					</option>
									<option value="2" <#
						if ( 2 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						2					</option>
									<option value="3" <#
						if ( 3 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						3					</option>
									<option value="4" <#
						if ( 4 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						4					</option>
									<option value="5" <#
						if ( 5 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						5					</option>
									<option value="6" <#
						if ( 6 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						6					</option>
									<option value="7" <#
						if ( 7 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						7					</option>
									<option value="8" <#
						if ( 8 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						8					</option>
									<option value="9" <#
						if ( 9 == wp.media.galleryDefaults.columns ) { #>selected="selected"<# }
					#>>
						9					</option>
							</select>
		</span>

		<span class="setting">
			<input type="checkbox" id="gallery-settings-random-order" data-setting="_orderbyRandom" />
			<label for="gallery-settings-random-order" class="checkbox-label-inline">Random Order</label>
		</span>

		<span class="setting size">
			<label for="gallery-settings-size" class="name">Size</label>
			<select id="gallery-settings-size" class="size" name="size"
				data-setting="size"
				<# if ( data.userSettings ) { #>
					data-user-setting="imgsize"
				<# } #>
				>
									<option value="thumbnail">
						Thumbnail					</option>
									<option value="medium">
						Medium					</option>
									<option value="large">
						Large					</option>
									<option value="full">
						Full Size					</option>
							</select>
		</span>
	</script>

		<script type="text/html" id="tmpl-playlist-settings">
		<h2>Playlist Settings</h2>

		<# var emptyModel = _.isEmpty( data.model ),
			isVideo = 'video' === data.controller.get('library').props.get('type'); #>

		<span class="setting">
			<input type="checkbox" id="playlist-settings-show-list" data-setting="tracklist" <# if ( emptyModel ) { #>
				checked="checked"
			<# } #> />
			<label for="playlist-settings-show-list" class="checkbox-label-inline">
				<# if ( isVideo ) { #>
				Show Video List				<# } else { #>
				Show Tracklist				<# } #>
			</label>
		</span>

		<# if ( ! isVideo ) { #>
		<span class="setting">
			<input type="checkbox" id="playlist-settings-show-artist" data-setting="artists" <# if ( emptyModel ) { #>
				checked="checked"
			<# } #> />
			<label for="playlist-settings-show-artist" class="checkbox-label-inline">
				Show Artist Name in Tracklist			</label>
		</span>
		<# } #>

		<span class="setting">
			<input type="checkbox" id="playlist-settings-show-images" data-setting="images" <# if ( emptyModel ) { #>
				checked="checked"
			<# } #> />
			<label for="playlist-settings-show-images" class="checkbox-label-inline">
				Show Images			</label>
		</span>
	</script>

		<script type="text/html" id="tmpl-embed-link-settings">
		<span class="setting link-text">
			<label for="embed-link-settings-link-text" class="name">Link Text</label>
			<input type="text" id="embed-link-settings-link-text" class="alignment" data-setting="linkText" />
		</span>
		<div class="embed-container" style="display: none;">
			<div class="embed-preview"></div>
		</div>
	</script>

		<script type="text/html" id="tmpl-embed-image-settings">
		<div class="wp-clearfix">
			<div class="thumbnail">
				<img src="{{ data.model.url }}" draggable="false" alt="" />
			</div>
		</div>

		<span class="setting alt-text has-description">
			<label for="embed-image-settings-alt-text" class="name">Alternative Text</label>
			<input type="text" id="embed-image-settings-alt-text" data-setting="alt" aria-describedby="alt-text-description" />
		</span>
		<p class="description" id="alt-text-description"><a href="https://www.w3.org/WAI/tutorials/images/decision-tree" target="_blank" rel="noopener">Learn how to describe the purpose of the image<span class="screen-reader-text"> (opens in a new tab)</span></a>. Leave empty if the image is purely decorative.</p>

					<span class="setting caption">
				<label for="embed-image-settings-caption" class="name">Caption</label>
				<textarea id="embed-image-settings-caption" data-setting="caption"></textarea>
			</span>
		
		<fieldset class="setting-group">
			<legend class="name">Align</legend>
			<span class="setting align">
				<span class="button-group button-large" data-setting="align">
					<button class="button" value="left">
						Left					</button>
					<button class="button" value="center">
						Center					</button>
					<button class="button" value="right">
						Right					</button>
					<button class="button active" value="none">
						None					</button>
				</span>
			</span>
		</fieldset>

		<fieldset class="setting-group">
			<legend class="name">Link To</legend>
			<span class="setting link-to">
				<span class="button-group button-large" data-setting="link">
					<button class="button" value="file">
						Image URL					</button>
					<button class="button" value="custom">
						Custom URL					</button>
					<button class="button active" value="none">
						None					</button>
				</span>
			</span>
			<span class="setting">
				<label for="embed-image-settings-link-to-custom" class="name">URL</label>
				<input type="text" id="embed-image-settings-link-to-custom" class="link-to-custom" data-setting="linkUrl" />
			</span>
		</fieldset>
	</script>

		<script type="text/html" id="tmpl-image-details">
		<div class="media-embed">
			<div class="embed-media-settings">
				<div class="column-settings">
					<span class="setting alt-text has-description">
						<label for="image-details-alt-text" class="name">Alternative Text</label>
						<input type="text" id="image-details-alt-text" data-setting="alt" value="{{ data.model.alt }}" aria-describedby="alt-text-description" />
					</span>
					<p class="description" id="alt-text-description"><a href="https://www.w3.org/WAI/tutorials/images/decision-tree" target="_blank" rel="noopener">Learn how to describe the purpose of the image<span class="screen-reader-text"> (opens in a new tab)</span></a>. Leave empty if the image is purely decorative.</p>

											<span class="setting caption">
							<label for="image-details-caption" class="name">Caption</label>
							<textarea id="image-details-caption" data-setting="caption">{{ data.model.caption }}</textarea>
						</span>
					
					<h2>Display Settings</h2>
					<fieldset class="setting-group">
						<legend class="legend-inline">Align</legend>
						<span class="setting align">
							<span class="button-group button-large" data-setting="align">
								<button class="button" value="left">
									Left								</button>
								<button class="button" value="center">
									Center								</button>
								<button class="button" value="right">
									Right								</button>
								<button class="button active" value="none">
									None								</button>
							</span>
						</span>
					</fieldset>

					<# if ( data.attachment ) { #>
						<# if ( 'undefined' !== typeof data.attachment.sizes ) { #>
							<span class="setting size">
								<label for="image-details-size" class="name">Size</label>
								<select id="image-details-size" class="size" name="size"
									data-setting="size"
									<# if ( data.userSettings ) { #>
										data-user-setting="imgsize"
									<# } #>>
																			<#
										var size = data.sizes['thumbnail'];
										if ( size ) { #>
											<option value="thumbnail">
												Thumbnail &ndash; {{ size.width }} &times; {{ size.height }}
											</option>
										<# } #>
																			<#
										var size = data.sizes['medium'];
										if ( size ) { #>
											<option value="medium">
												Medium &ndash; {{ size.width }} &times; {{ size.height }}
											</option>
										<# } #>
																			<#
										var size = data.sizes['large'];
										if ( size ) { #>
											<option value="large">
												Large &ndash; {{ size.width }} &times; {{ size.height }}
											</option>
										<# } #>
																			<#
										var size = data.sizes['full'];
										if ( size ) { #>
											<option value="full">
												Full Size &ndash; {{ size.width }} &times; {{ size.height }}
											</option>
										<# } #>
																		<option value="custom">
										Custom Size									</option>
								</select>
							</span>
						<# } #>
							<div class="custom-size wp-clearfix<# if ( data.model.size !== 'custom' ) { #> hidden<# } #>">
								<span class="custom-size-setting">
									<label for="image-details-size-width">Width</label>
									<input type="number" id="image-details-size-width" aria-describedby="image-size-desc" data-setting="customWidth" step="1" value="{{ data.model.customWidth }}" />
								</span>
								<span class="sep" aria-hidden="true">&times;</span>
								<span class="custom-size-setting">
									<label for="image-details-size-height">Height</label>
									<input type="number" id="image-details-size-height" aria-describedby="image-size-desc" data-setting="customHeight" step="1" value="{{ data.model.customHeight }}" />
								</span>
								<p id="image-size-desc" class="description">Image size in pixels</p>
							</div>
					<# } #>

					<span class="setting link-to">
						<label for="image-details-link-to" class="name">Link To</label>
						<select id="image-details-link-to" data-setting="link">
						<# if ( data.attachment ) { #>
							<option value="file">
								Media File							</option>
							<option value="post">
								Attachment Page							</option>
						<# } else { #>
							<option value="file">
								Image URL							</option>
						<# } #>
							<option value="custom">
								Custom URL							</option>
							<option value="none">
								None							</option>
						</select>
					</span>
					<span class="setting">
						<label for="image-details-link-to-custom" class="name">URL</label>
						<input type="text" id="image-details-link-to-custom" class="link-to-custom" data-setting="linkUrl" />
					</span>

					<div class="advanced-section">
						<h2><button type="button" class="button-link advanced-toggle">Advanced Options</button></h2>
						<div class="advanced-settings hidden">
							<div class="advanced-image">
								<span class="setting title-text">
									<label for="image-details-title-attribute" class="name">Image Title Attribute</label>
									<input type="text" id="image-details-title-attribute" data-setting="title" value="{{ data.model.title }}" />
								</span>
								<span class="setting extra-classes">
									<label for="image-details-css-class" class="name">Image CSS Class</label>
									<input type="text" id="image-details-css-class" data-setting="extraClasses" value="{{ data.model.extraClasses }}" />
								</span>
							</div>
							<div class="advanced-link">
								<span class="setting link-target">
									<input type="checkbox" id="image-details-link-target" data-setting="linkTargetBlank" value="_blank" <# if ( data.model.linkTargetBlank ) { #>checked="checked"<# } #>>
									<label for="image-details-link-target" class="checkbox-label">Open link in a new tab</label>
								</span>
								<span class="setting link-rel">
									<label for="image-details-link-rel" class="name">Link Rel</label>
									<input type="text" id="image-details-link-rel" data-setting="linkRel" value="{{ data.model.linkRel }}" />
								</span>
								<span class="setting link-class-name">
									<label for="image-details-link-css-class" class="name">Link CSS Class</label>
									<input type="text" id="image-details-link-css-class" data-setting="linkClassName" value="{{ data.model.linkClassName }}" />
								</span>
							</div>
						</div>
					</div>
				</div>
				<div class="column-image">
					<div class="image">
						<img src="{{ data.model.url }}" draggable="false" alt="" />
						<# if ( data.attachment && window.imageEdit ) { #>
							<div class="actions">
								<input type="button" class="edit-attachment button" value="Edit Original" />
								<input type="button" class="replace-attachment button" value="Replace" />
							</div>
						<# } #>
					</div>
				</div>
			</div>
		</div>
	</script>

		<script type="text/html" id="tmpl-image-editor">
		<div id="media-head-{{ data.id }}"></div>
		<div id="image-editor-{{ data.id }}"></div>
	</script>

		<script type="text/html" id="tmpl-audio-details">
		<# var ext, html5types = {
			mp3: wp.media.view.settings.embedMimes.mp3,
			ogg: wp.media.view.settings.embedMimes.ogg
		}; #>

				<div class="media-embed media-embed-details">
			<div class="embed-media-settings embed-audio-settings">
				<audio style="visibility: hidden"
	controls
	class="wp-audio-shortcode"
	width="{{ _.isUndefined( data.model.width ) ? 400 : data.model.width }}"
	preload="{{ _.isUndefined( data.model.preload ) ? 'none' : data.model.preload }}"
	<#
		if ( ! _.isUndefined( data.model.autoplay ) && data.model.autoplay ) {
		#> autoplay<#
	}
		if ( ! _.isUndefined( data.model.loop ) && data.model.loop ) {
		#> loop<#
	}
	#>
>
	<# if ( ! _.isEmpty( data.model.src ) ) { #>
	<source src="{{ data.model.src }}" type="{{ wp.media.view.settings.embedMimes[ data.model.src.split('.').pop() ] }}" />
	<# } #>

		<# if ( ! _.isEmpty( data.model.mp3 ) ) { #>
	<source src="{{ data.model.mp3 }}" type="{{ wp.media.view.settings.embedMimes[ 'mp3' ] }}" />
	<# } #>
			<# if ( ! _.isEmpty( data.model.ogg ) ) { #>
	<source src="{{ data.model.ogg }}" type="{{ wp.media.view.settings.embedMimes[ 'ogg' ] }}" />
	<# } #>
			<# if ( ! _.isEmpty( data.model.flac ) ) { #>
	<source src="{{ data.model.flac }}" type="{{ wp.media.view.settings.embedMimes[ 'flac' ] }}" />
	<# } #>
			<# if ( ! _.isEmpty( data.model.m4a ) ) { #>
	<source src="{{ data.model.m4a }}" type="{{ wp.media.view.settings.embedMimes[ 'm4a' ] }}" />
	<# } #>
			<# if ( ! _.isEmpty( data.model.wav ) ) { #>
	<source src="{{ data.model.wav }}" type="{{ wp.media.view.settings.embedMimes[ 'wav' ] }}" />
	<# } #>
		</audio>
	
				<# if ( ! _.isEmpty( data.model.src ) ) {
					ext = data.model.src.split('.').pop();
					if ( html5types[ ext ] ) {
						delete html5types[ ext ];
					}
				#>
				<span class="setting">
					<label for="audio-details-source" class="name">URL</label>
					<input type="text" id="audio-details-source" readonly data-setting="src" value="{{ data.model.src }}" />
					<button type="button" class="button-link remove-setting">Remove audio source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.mp3 ) ) {
					if ( ! _.isUndefined( html5types.mp3 ) ) {
						delete html5types.mp3;
					}
				#>
				<span class="setting">
					<label for="audio-details-mp3-source" class="name">MP3</label>
					<input type="text" id="audio-details-mp3-source" readonly data-setting="mp3" value="{{ data.model.mp3 }}" />
					<button type="button" class="button-link remove-setting">Remove audio source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.ogg ) ) {
					if ( ! _.isUndefined( html5types.ogg ) ) {
						delete html5types.ogg;
					}
				#>
				<span class="setting">
					<label for="audio-details-ogg-source" class="name">OGG</label>
					<input type="text" id="audio-details-ogg-source" readonly data-setting="ogg" value="{{ data.model.ogg }}" />
					<button type="button" class="button-link remove-setting">Remove audio source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.flac ) ) {
					if ( ! _.isUndefined( html5types.flac ) ) {
						delete html5types.flac;
					}
				#>
				<span class="setting">
					<label for="audio-details-flac-source" class="name">FLAC</label>
					<input type="text" id="audio-details-flac-source" readonly data-setting="flac" value="{{ data.model.flac }}" />
					<button type="button" class="button-link remove-setting">Remove audio source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.m4a ) ) {
					if ( ! _.isUndefined( html5types.m4a ) ) {
						delete html5types.m4a;
					}
				#>
				<span class="setting">
					<label for="audio-details-m4a-source" class="name">M4A</label>
					<input type="text" id="audio-details-m4a-source" readonly data-setting="m4a" value="{{ data.model.m4a }}" />
					<button type="button" class="button-link remove-setting">Remove audio source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.wav ) ) {
					if ( ! _.isUndefined( html5types.wav ) ) {
						delete html5types.wav;
					}
				#>
				<span class="setting">
					<label for="audio-details-wav-source" class="name">WAV</label>
					<input type="text" id="audio-details-wav-source" readonly data-setting="wav" value="{{ data.model.wav }}" />
					<button type="button" class="button-link remove-setting">Remove audio source</button>
				</span>
				<# } #>
				
				<# if ( ! _.isEmpty( html5types ) ) { #>
				<fieldset class="setting-group">
					<legend class="name">Add alternate sources for maximum HTML5 playback</legend>
					<span class="setting">
						<span class="button-large">
						<# _.each( html5types, function (mime, type) { #>
							<button class="button add-media-source" data-mime="{{ mime }}">{{ type }}</button>
						<# } ) #>
						</span>
					</span>
				</fieldset>
				<# } #>

				<fieldset class="setting-group">
					<legend class="name">Preload</legend>
					<span class="setting preload">
						<span class="button-group button-large" data-setting="preload">
							<button class="button" value="auto">Auto</button>
							<button class="button" value="metadata">Metadata</button>
							<button class="button active" value="none">None</button>
						</span>
					</span>
				</fieldset>

				<span class="setting-group">
					<span class="setting checkbox-setting autoplay">
						<input type="checkbox" id="audio-details-autoplay" data-setting="autoplay" />
						<label for="audio-details-autoplay" class="checkbox-label">Autoplay</label>
					</span>

					<span class="setting checkbox-setting">
						<input type="checkbox" id="audio-details-loop" data-setting="loop" />
						<label for="audio-details-loop" class="checkbox-label">Loop</label>
					</span>
				</span>
			</div>
		</div>
	</script>

		<script type="text/html" id="tmpl-video-details">
		<# var ext, html5types = {
			mp4: wp.media.view.settings.embedMimes.mp4,
			ogv: wp.media.view.settings.embedMimes.ogv,
			webm: wp.media.view.settings.embedMimes.webm
		}; #>

				<div class="media-embed media-embed-details">
			<div class="embed-media-settings embed-video-settings">
				<div class="wp-video-holder">
				<#
				var w = ! data.model.width || data.model.width > 640 ? 640 : data.model.width,
					h = ! data.model.height ? 360 : data.model.height;

				if ( data.model.width && w !== data.model.width ) {
					h = Math.ceil( ( h * w ) / data.model.width );
				}
				#>

				<#  var w_rule = '', classes = [],
		w, h, settings = wp.media.view.settings,
		isYouTube = isVimeo = false;

	if ( ! _.isEmpty( data.model.src ) ) {
		isYouTube = data.model.src.match(/youtube|youtu\.be/);
		isVimeo = -1 !== data.model.src.indexOf('vimeo');
	}

	if ( settings.contentWidth && data.model.width >= settings.contentWidth ) {
		w = settings.contentWidth;
	} else {
		w = data.model.width;
	}

	if ( w !== data.model.width ) {
		h = Math.ceil( ( data.model.height * w ) / data.model.width );
	} else {
		h = data.model.height;
	}

	if ( w ) {
		w_rule = 'width: ' + w + 'px; ';
	}

	if ( isYouTube ) {
		classes.push( 'youtube-video' );
	}

	if ( isVimeo ) {
		classes.push( 'vimeo-video' );
	}

#>
<div style="{{ w_rule }}" class="wp-video">
<video controls
	class="wp-video-shortcode {{ classes.join( ' ' ) }}"
	<# if ( w ) { #>width="{{ w }}"<# } #>
	<# if ( h ) { #>height="{{ h }}"<# } #>
			<#
		if ( ! _.isUndefined( data.model.poster ) && data.model.poster ) {
			#> poster="{{ data.model.poster }}"<#
		} #>
			preload			="{{ _.isUndefined( data.model.preload ) ? 'metadata' : data.model.preload }}"
				<#
		if ( ! _.isUndefined( data.model.autoplay ) && data.model.autoplay ) {
		#> autoplay<#
	}
		if ( ! _.isUndefined( data.model.loop ) && data.model.loop ) {
		#> loop<#
	}
	#>
>
	<# if ( ! _.isEmpty( data.model.src ) ) {
		if ( isYouTube ) { #>
		<source src="{{ data.model.src }}" type="video/youtube" />
		<# } else if ( isVimeo ) { #>
		<source src="{{ data.model.src }}" type="video/vimeo" />
		<# } else { #>
		<source src="{{ data.model.src }}" type="{{ settings.embedMimes[ data.model.src.split('.').pop() ] }}" />
		<# }
	} #>

		<# if ( data.model.mp4 ) { #>
	<source src="{{ data.model.mp4 }}" type="{{ settings.embedMimes[ 'mp4' ] }}" />
	<# } #>
		<# if ( data.model.m4v ) { #>
	<source src="{{ data.model.m4v }}" type="{{ settings.embedMimes[ 'm4v' ] }}" />
	<# } #>
		<# if ( data.model.webm ) { #>
	<source src="{{ data.model.webm }}" type="{{ settings.embedMimes[ 'webm' ] }}" />
	<# } #>
		<# if ( data.model.ogv ) { #>
	<source src="{{ data.model.ogv }}" type="{{ settings.embedMimes[ 'ogv' ] }}" />
	<# } #>
		<# if ( data.model.flv ) { #>
	<source src="{{ data.model.flv }}" type="{{ settings.embedMimes[ 'flv' ] }}" />
	<# } #>
		{{{ data.model.content }}}
</video>
</div>
	
				<# if ( ! _.isEmpty( data.model.src ) ) {
					ext = data.model.src.split('.').pop();
					if ( html5types[ ext ] ) {
						delete html5types[ ext ];
					}
				#>
				<span class="setting">
					<label for="video-details-source" class="name">URL</label>
					<input type="text" id="video-details-source" readonly data-setting="src" value="{{ data.model.src }}" />
					<button type="button" class="button-link remove-setting">Remove video source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.mp4 ) ) {
					if ( ! _.isUndefined( html5types.mp4 ) ) {
						delete html5types.mp4;
					}
				#>
				<span class="setting">
					<label for="video-details-mp4-source" class="name">MP4</label>
					<input type="text" id="video-details-mp4-source" readonly data-setting="mp4" value="{{ data.model.mp4 }}" />
					<button type="button" class="button-link remove-setting">Remove video source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.m4v ) ) {
					if ( ! _.isUndefined( html5types.m4v ) ) {
						delete html5types.m4v;
					}
				#>
				<span class="setting">
					<label for="video-details-m4v-source" class="name">M4V</label>
					<input type="text" id="video-details-m4v-source" readonly data-setting="m4v" value="{{ data.model.m4v }}" />
					<button type="button" class="button-link remove-setting">Remove video source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.webm ) ) {
					if ( ! _.isUndefined( html5types.webm ) ) {
						delete html5types.webm;
					}
				#>
				<span class="setting">
					<label for="video-details-webm-source" class="name">WEBM</label>
					<input type="text" id="video-details-webm-source" readonly data-setting="webm" value="{{ data.model.webm }}" />
					<button type="button" class="button-link remove-setting">Remove video source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.ogv ) ) {
					if ( ! _.isUndefined( html5types.ogv ) ) {
						delete html5types.ogv;
					}
				#>
				<span class="setting">
					<label for="video-details-ogv-source" class="name">OGV</label>
					<input type="text" id="video-details-ogv-source" readonly data-setting="ogv" value="{{ data.model.ogv }}" />
					<button type="button" class="button-link remove-setting">Remove video source</button>
				</span>
				<# } #>
								<# if ( ! _.isEmpty( data.model.flv ) ) {
					if ( ! _.isUndefined( html5types.flv ) ) {
						delete html5types.flv;
					}
				#>
				<span class="setting">
					<label for="video-details-flv-source" class="name">FLV</label>
					<input type="text" id="video-details-flv-source" readonly data-setting="flv" value="{{ data.model.flv }}" />
					<button type="button" class="button-link remove-setting">Remove video source</button>
				</span>
				<# } #>
								</div>

				<# if ( ! _.isEmpty( html5types ) ) { #>
				<fieldset class="setting-group">
					<legend class="name">Add alternate sources for maximum HTML5 playback</legend>
					<span class="setting">
						<span class="button-large">
						<# _.each( html5types, function (mime, type) { #>
							<button class="button add-media-source" data-mime="{{ mime }}">{{ type }}</button>
						<# } ) #>
						</span>
					</span>
				</fieldset>
				<# } #>

				<# if ( ! _.isEmpty( data.model.poster ) ) { #>
				<span class="setting">
					<label for="video-details-poster-image" class="name">Poster Image</label>
					<input type="text" id="video-details-poster-image" readonly data-setting="poster" value="{{ data.model.poster }}" />
					<button type="button" class="button-link remove-setting">Remove poster image</button>
				</span>
				<# } #>

				<fieldset class="setting-group">
					<legend class="name">Preload</legend>
					<span class="setting preload">
						<span class="button-group button-large" data-setting="preload">
							<button class="button" value="auto">Auto</button>
							<button class="button" value="metadata">Metadata</button>
							<button class="button active" value="none">None</button>
						</span>
					</span>
				</fieldset>

				<span class="setting-group">
					<span class="setting checkbox-setting autoplay">
						<input type="checkbox" id="video-details-autoplay" data-setting="autoplay" />
						<label for="video-details-autoplay" class="checkbox-label">Autoplay</label>
					</span>

					<span class="setting checkbox-setting">
						<input type="checkbox" id="video-details-loop" data-setting="loop" />
						<label for="video-details-loop" class="checkbox-label">Loop</label>
					</span>
				</span>

				<span class="setting" data-setting="content">
					<#
					var content = '';
					if ( ! _.isEmpty( data.model.content ) ) {
						var tracks = jQuery( data.model.content ).filter( 'track' );
						_.each( tracks.toArray(), function( track, index ) {
							content += track.outerHTML; #>
						<label for="video-details-track-{{ index }}" class="name">Tracks (subtitles, captions, descriptions, chapters, or metadata)</label>
						<input class="content-track" type="text" id="video-details-track-{{ index }}" aria-describedby="video-details-track-desc-{{ index }}" value="{{ track.outerHTML }}" />
						<span class="description" id="video-details-track-desc-{{ index }}">
						The srclang, label, and kind values can be edited to set the video track language and kind.						</span>
						<button type="button" class="button-link remove-setting remove-track">Remove video track</button><br/>
						<# } ); #>
					<# } else { #>
					<span class="name">Tracks (subtitles, captions, descriptions, chapters, or metadata)</span><br />
					<em>There are no associated subtitles.</em>
					<# } #>
					<textarea class="hidden content-setting">{{ content }}</textarea>
				</span>
			</div>
		</div>
	</script>

		<script type="text/html" id="tmpl-editor-gallery">
		<# if ( data.attachments.length ) { #>
			<div class="gallery gallery-columns-{{ data.columns }}">
				<# _.each( data.attachments, function( attachment, index ) { #>
					<dl class="gallery-item">
						<dt class="gallery-icon">
							<# if ( attachment.thumbnail ) { #>
								<img src="{{ attachment.thumbnail.url }}" width="{{ attachment.thumbnail.width }}" height="{{ attachment.thumbnail.height }}" alt="{{ attachment.alt }}" />
							<# } else { #>
								<img src="{{ attachment.url }}" alt="{{ attachment.alt }}" />
							<# } #>
						</dt>
						<# if ( attachment.caption ) { #>
							<dd class="wp-caption-text gallery-caption">
								{{{ data.verifyHTML( attachment.caption ) }}}
							</dd>
						<# } #>
					</dl>
					<# if ( index % data.columns === data.columns - 1 ) { #>
						<br style="clear: both;">
					<# } #>
				<# } ); #>
			</div>
		<# } else { #>
			<div class="wpview-error">
				<div class="dashicons dashicons-format-gallery"></div><p>No items found.</p>
			</div>
		<# } #>
	</script>

		<script type="text/html" id="tmpl-crop-content">
		<img class="crop-image" src="{{ data.url }}" alt="Image crop area preview. Requires mouse interaction." />
		<div class="upload-errors"></div>
	</script>

		<script type="text/html" id="tmpl-site-icon-preview">
		<h2>Preview</h2>
		<strong aria-hidden="true">As a browser icon</strong>
		<div class="favicon-preview">
			<img src="https://brighter.techcraze.co.in/wp-admin/images/browser.png" class="browser-preview" width="182" height="" alt="" />

			<div class="favicon">
				<img id="preview-favicon" src="{{ data.url }}" alt="Preview as a browser icon" />
			</div>
			<span class="browser-title" aria-hidden="true"><# print( 'Brighter Skills' ) #></span>
		</div>

		<strong aria-hidden="true">As an app icon</strong>
		<div class="app-icon-preview">
			<img id="preview-app-icon" src="{{ data.url }}" alt="Preview as an app icon" />
		</div>
	</script>

		<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/qubely/assets/js/common-script.min.js?ver=1.7.8' id='qubely-block-common-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/qubely/assets/js/interaction.min.js?ver=1.7.8' id='qubely-interaction-js'></script>
<script type='text/javascript' id='quicktags-js-extra'>
/* <![CDATA[ */
var quicktagsL10n = {"closeAllOpenTags":"Close all open tags","closeTags":"close tags","enterURL":"Enter the URL","enterImageURL":"Enter the URL of the image","enterImageDescription":"Enter a description of the image","textdirection":"text direction","toggleTextdirection":"Toggle Editor Text Direction","dfw":"Distraction-free writing mode","strong":"Bold","strongClose":"Close bold tag","em":"Italic","emClose":"Close italic tag","link":"Insert link","blockquote":"Blockquote","blockquoteClose":"Close blockquote tag","del":"Deleted text (strikethrough)","delClose":"Close deleted text tag","ins":"Inserted text","insClose":"Close inserted text tag","image":"Insert image","ul":"Bulleted list","ulClose":"Close bulleted list tag","ol":"Numbered list","olClose":"Close numbered list tag","li":"List item","liClose":"Close list item tag","code":"Code","codeClose":"Close code tag","more":"Insert Read More tag"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/quicktags.min.js?ver=5.9' id='quicktags-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/jquery/ui/core.min.js?ver=1.13.0' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/jquery/ui/mouse.min.js?ver=1.13.0' id='jquery-ui-mouse-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/jquery/ui/sortable.min.js?ver=1.13.0' id='jquery-ui-sortable-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/packages/plyr/plyr.polyfilled.min.js?ver=1.9.3' id='tutor-plyr-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/packages/SocialShare/SocialShare.min.js?ver=1.9.3' id='tutor-social-share-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/dist/hooks.min.js?ver=1e58c8c5a32b2e97491080c5b10dc71c' id='wp-hooks-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/dist/i18n.min.js?ver=30fcecb428a0e8383d3776bcdd3a7834' id='wp-i18n-js'></script>
<script type='text/javascript' id='wp-i18n-js-after'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script type='text/javascript' id='tutor-main-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "tutor", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/js/tutor.js?ver=1.9.3' id='tutor-main-js'></script>
<script type='text/javascript' id='tutor-frontend-js-extra'>
/* <![CDATA[ */
var _tutorobject = {"ajaxurl":"https:\/\/brighter.techcraze.co.in\/wp-admin\/admin-ajax.php","home_url":"https:\/\/brighter.techcraze.co.in","base_path":"\/","tutor_url":"https:\/\/brighter.techcraze.co.in\/wp-content\/plugins\/tutor\/","nonce_key":"_tutor_nonce","_tutor_nonce":"408d35243c","placeholder_img_src":"https:\/\/brighter.techcraze.co.in\/wp-content\/plugins\/tutor\/assets\/images\/placeholder.jpg","enable_lesson_classic_editor":"","loading_icon_url":"https:\/\/brighter.techcraze.co.in\/wp-admin\/images\/loading.gif"};
/* ]]> */
</script>
<script type='text/javascript' id='tutor-frontend-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "tutor", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/tutor/assets/js/tutor-front.js?ver=1.9.3' id='tutor-frontend-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.13.0' id='jquery-ui-datepicker-js'></script>
<script type='text/javascript' id='jquery-ui-datepicker-js-after'>
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.6.1.1' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/brighter.techcraze.co.in\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=6.1.1' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.6.1.1' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=6.1.1' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_4e4d77b8ac04c93f33556c895a5a33d9","fragment_name":"wc_fragments_4e4d77b8ac04c93f33556c895a5a33d9","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=6.1.1' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='mailchimp-woocommerce-js-extra'>
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"https:\/\/brighter.techcraze.co.in","ajax_url":"https:\/\/brighter.techcraze.co.in\/wp-admin\/admin-ajax.php","language":"en","allowed_to_set_cookies":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js?ver=2.5.4' id='mailchimp-woocommerce-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/underscore.min.js?ver=1.13.1' id='underscore-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/shortcode.min.js?ver=5.9' id='shortcode-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/backbone.min.js?ver=1.4.0' id='backbone-js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/wp-util.min.js?ver=5.9' id='wp-util-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/wp-backbone.min.js?ver=5.9' id='wp-backbone-js'></script>
<script type='text/javascript' id='media-models-js-extra'>
/* <![CDATA[ */
var _wpMediaModelsL10n = {"settings":{"ajaxurl":"\/wp-admin\/admin-ajax.php","post":{"id":0}}};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/media-models.min.js?ver=5.9' id='media-models-js'></script>
<script type='text/javascript' id='wp-plupload-js-extra'>
/* <![CDATA[ */
var pluploadL10n = {"queue_limit_exceeded":"You have attempted to queue too many files.","file_exceeds_size_limit":"%s exceeds the maximum upload size for this site.","zero_byte_file":"This file is empty. Please try another.","invalid_filetype":"Sorry, you are not allowed to upload this file type.","not_an_image":"This file is not an image. Please try another.","image_memory_exceeded":"Memory exceeded. Please try another smaller file.","image_dimensions_exceeded":"This is larger than the maximum size. Please try another.","default_error":"An error occurred in the upload. Please try again later.","missing_upload_url":"There was a configuration error. Please contact the server administrator.","upload_limit_exceeded":"You may only upload 1 file.","http_error":"Unexpected response from the server. The file may have been uploaded successfully. Check in the Media Library or reload the page.","http_error_image":"The server cannot process the image. This can happen if the server is busy or does not have enough resources to complete the task. Uploading a smaller image may help. Suggested maximum size is 2560 pixels.","upload_failed":"Upload failed.","big_upload_failed":"Please try uploading this file with the %1$sbrowser uploader%2$s.","big_upload_queued":"%s exceeds the maximum upload size for the multi-file uploader when used in your browser.","io_error":"IO error.","security_error":"Security error.","file_cancelled":"File canceled.","upload_stopped":"Upload stopped.","dismiss":"Dismiss","crunching":"Crunching\u2026","deleted":"moved to the Trash.","error_uploading":"\u201c%s\u201d has failed to upload.","unsupported_image":"This image cannot be displayed in a web browser. For best results convert it to JPEG before uploading.","noneditable_image":"This image cannot be processed by the web server. Convert it to JPEG or PNG before uploading.","file_url_copied":"The file URL has been copied to your clipboard"};
var _wpPluploadSettings = {"defaults":{"file_data_name":"async-upload","url":"\/wp-admin\/async-upload.php","filters":{"max_file_size":"8388608b","mime_types":[{"extensions":"jpg,jpeg,jpe,gif,png,bmp,tiff,tif,webp,ico,heic,asf,asx,wmv,wmx,wm,avi,divx,flv,mov,qt,mpeg,mpg,mpe,mp4,m4v,ogv,webm,mkv,3gp,3gpp,3g2,3gp2,txt,asc,c,cc,h,srt,csv,tsv,ics,rtx,css,vtt,dfxp,mp3,m4a,m4b,aac,ra,ram,wav,ogg,oga,flac,mid,midi,wma,wax,mka,rtf,pdf,class,tar,zip,gz,gzip,rar,7z,psd,xcf,doc,pot,pps,ppt,wri,xla,xls,xlt,xlw,mdb,mpp,docx,docm,dotx,dotm,xlsx,xlsm,xlsb,xltx,xltm,xlam,pptx,pptm,ppsx,ppsm,potx,potm,ppam,sldx,sldm,onetoc,onetoc2,onetmp,onepkg,oxps,xps,odt,odp,ods,odg,odc,odb,odf,wp,wpd,key,numbers,pages"}]},"heic_upload_error":true,"multipart_params":{"action":"upload-attachment","_wpnonce":"1466d0f06c"}},"browser":{"mobile":false,"supported":true},"limitExceeded":false};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/plupload/wp-plupload.min.js?ver=5.9' id='wp-plupload-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.16' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=5.9' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=5.9' id='wp-mediaelement-js'></script>
<script type='text/javascript' id='wp-api-request-js-extra'>
/* <![CDATA[ */
var wpApiSettings = {"root":"https:\/\/brighter.techcraze.co.in\/wp-json\/","nonce":"f3bd22bb90","versionString":"wp\/v2\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/api-request.min.js?ver=5.9' id='wp-api-request-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/dist/dom-ready.min.js?ver=ecda74de0221e1c2ce5c57cbb5af09d5' id='wp-dom-ready-js'></script>
<script type='text/javascript' id='wp-a11y-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/dist/a11y.min.js?ver=68e470cf840f69530e9db3be229ad4b6' id='wp-a11y-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/clipboard.min.js?ver=5.9' id='clipboard-js'></script>
<script type='text/javascript' id='media-views-js-extra'>
/* <![CDATA[ */
var _wpMediaViewsL10n = {"mediaFrameDefaultTitle":"Media","url":"URL","addMedia":"Add media","search":"Search","select":"Select","cancel":"Cancel","update":"Update","replace":"Replace","remove":"Remove","back":"Back","selected":"%d selected","dragInfo":"Drag and drop to reorder media files.","uploadFilesTitle":"Upload files","uploadImagesTitle":"Upload images","mediaLibraryTitle":"Media Library","insertMediaTitle":"Add media","createNewGallery":"Create a new gallery","createNewPlaylist":"Create a new playlist","createNewVideoPlaylist":"Create a new video playlist","returnToLibrary":"\u2190 Go to library","allMediaItems":"All media items","allDates":"All dates","noItemsFound":"No items found.","insertIntoPost":"Insert into post","unattached":"Unattached","mine":"Mine","trash":"Trash","uploadedToThisPost":"Uploaded to this post","warnDelete":"You are about to permanently delete this item from your site.\nThis action cannot be undone.\n 'Cancel' to stop, 'OK' to delete.","warnBulkDelete":"You are about to permanently delete these items from your site.\nThis action cannot be undone.\n 'Cancel' to stop, 'OK' to delete.","warnBulkTrash":"You are about to trash these items.\n  'Cancel' to stop, 'OK' to delete.","bulkSelect":"Bulk select","trashSelected":"Move to Trash","restoreSelected":"Restore from Trash","deletePermanently":"Delete permanently","apply":"Apply","filterByDate":"Filter by date","filterByType":"Filter by type","searchLabel":"Search","searchMediaLabel":"Search media","searchMediaPlaceholder":"Search media items...","mediaFound":"Number of media items found: %d","noMedia":"No media items found.","noMediaTryNewSearch":"No media items found. Try a different search.","attachmentDetails":"Attachment details","insertFromUrlTitle":"Insert from URL","setFeaturedImageTitle":"Featured image","setFeaturedImage":"Set featured image","createGalleryTitle":"Create gallery","editGalleryTitle":"Edit gallery","cancelGalleryTitle":"\u2190 Cancel gallery","insertGallery":"Insert gallery","updateGallery":"Update gallery","addToGallery":"Add to gallery","addToGalleryTitle":"Add to gallery","reverseOrder":"Reverse order","imageDetailsTitle":"Image details","imageReplaceTitle":"Replace image","imageDetailsCancel":"Cancel edit","editImage":"Edit image","chooseImage":"Choose image","selectAndCrop":"Select and crop","skipCropping":"Skip cropping","cropImage":"Crop image","cropYourImage":"Crop your image","cropping":"Cropping\u2026","suggestedDimensions":"Suggested image dimensions: %1$s by %2$s pixels.","cropError":"There has been an error cropping your image.","audioDetailsTitle":"Audio details","audioReplaceTitle":"Replace audio","audioAddSourceTitle":"Add audio source","audioDetailsCancel":"Cancel edit","videoDetailsTitle":"Video details","videoReplaceTitle":"Replace video","videoAddSourceTitle":"Add video source","videoDetailsCancel":"Cancel edit","videoSelectPosterImageTitle":"Select poster image","videoAddTrackTitle":"Add subtitles","playlistDragInfo":"Drag and drop to reorder tracks.","createPlaylistTitle":"Create audio playlist","editPlaylistTitle":"Edit audio playlist","cancelPlaylistTitle":"\u2190 Cancel audio playlist","insertPlaylist":"Insert audio playlist","updatePlaylist":"Update audio playlist","addToPlaylist":"Add to audio playlist","addToPlaylistTitle":"Add to Audio Playlist","videoPlaylistDragInfo":"Drag and drop to reorder videos.","createVideoPlaylistTitle":"Create video playlist","editVideoPlaylistTitle":"Edit video playlist","cancelVideoPlaylistTitle":"\u2190 Cancel video playlist","insertVideoPlaylist":"Insert video playlist","updateVideoPlaylist":"Update video playlist","addToVideoPlaylist":"Add to video playlist","addToVideoPlaylistTitle":"Add to video Playlist","filterAttachments":"Filter media","attachmentsList":"Media list","settings":{"tabs":[],"tabUrl":"https:\/\/brighter.techcraze.co.in\/wp-admin\/media-upload.php?chromeless=1","mimeTypes":{"image":"Images","audio":"Audio","video":"Video","application\/msword,application\/vnd.openxmlformats-officedocument.wordprocessingml.document,application\/vnd.ms-word.document.macroEnabled.12,application\/vnd.ms-word.template.macroEnabled.12,application\/vnd.oasis.opendocument.text,application\/vnd.apple.pages,application\/pdf,application\/vnd.ms-xpsdocument,application\/oxps,application\/rtf,application\/wordperfect,application\/octet-stream":"Documents","application\/vnd.apple.numbers,application\/vnd.oasis.opendocument.spreadsheet,application\/vnd.ms-excel,application\/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application\/vnd.ms-excel.sheet.macroEnabled.12,application\/vnd.ms-excel.sheet.binary.macroEnabled.12":"Spreadsheets","application\/x-gzip,application\/rar,application\/x-tar,application\/zip,application\/x-7z-compressed":"Archives"},"captions":true,"nonce":{"sendToEditor":"5833a90a51"},"post":{"id":0},"defaultProps":{"link":"none","align":"","size":""},"attachmentCounts":{"audio":1,"video":1},"oEmbedProxyUrl":"https:\/\/brighter.techcraze.co.in\/wp-json\/oembed\/1.0\/proxy","embedExts":["mp3","ogg","flac","m4a","wav","mp4","m4v","webm","ogv","flv"],"embedMimes":{"mp3":"audio\/mpeg","ogg":"audio\/ogg","flac":"audio\/flac","m4a":"audio\/mpeg","wav":"audio\/wav","mp4":"video\/mp4","m4v":"video\/mp4","webm":"video\/webm","ogv":"video\/ogg","flv":"video\/x-flv"},"contentWidth":null,"months":[{"year":"2021","month":"7","text":"July 2021"},{"year":"2021","month":"6","text":"June 2021"},{"year":"2021","month":"5","text":"May 2021"}],"mediaTrash":0,"infiniteScrolling":0}};
/* ]]> */
</script>
<script type='text/javascript' id='media-views-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/media-views.min.js?ver=5.9' id='media-views-js'></script>
<script type='text/javascript' id='media-editor-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/media-editor.min.js?ver=5.9' id='media-editor-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-includes/js/media-audiovideo.min.js?ver=5.9' id='media-audiovideo-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/themes/docent/js/bootstrap.min.js?ver=5.9' id='bootstrap-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/themes/docent/js/main.js?ver=5.9' id='docent-main-js'></script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/assets/js/main.js?ver=5.9' id='wppagebuilder-main-js'></script>
<script type='text/javascript' id='wppb-posts-addon-js-extra'>
/* <![CDATA[ */
var wppb_posts_addon = {"ajax_url":"https:\/\/brighter.techcraze.co.in\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brighter.techcraze.co.in/wp-content/plugins/wp-pagebuilder/addons/posts/assets/js/posts-addon.js?ver=5.9' id='wppb-posts-addon-js'></script>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	</body>
</html>
